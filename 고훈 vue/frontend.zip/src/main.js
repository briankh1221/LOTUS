import { createApp } from 'vue';
import { createPinia } from 'pinia';

import App from './App.vue';
import router from '@/router';
import socket from 'vue3-websocket';

import 'bootstrap/dist/css/bootstrap.css'; // 부트스트랩 CSS 임포트
import 'bootstrap/dist/js/bootstrap.bundle.min.js'; // 부트스트랩 JS 임포트

const app = createApp(App);

app.use(createPinia());
app.use(router);
// app.use(socket, 'ws://localhost:8081/user/chat');

app.mount('#app');
