<template>
  <div v-if="post">
    <br /><br />

    <div class="row">
      <!-- 사진 슬라이드 부분 -->
      <div class="col-6">
        <div id="carouselExample" class="carousel slide">
          <div class="carousel-inner">
            <div
              v-for="(image, idx) in post.images.split(' ')"
              :key="idx"
              class="carousel-item"
              :class="{ active: idx === 0 }"
            >
              <img
                :src="'/images/' + image"
                class="d-block w-100 rounded-3"
                style="height: 400px"
              />
            </div>
          </div>
          <div v-if="post.images.split(' ').length > 1">
            <button
              class="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExample"
              data-bs-slide="prev"
            >
              <span
                class="carousel-control-prev-icon"
                aria-hidden="true"
              ></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button
              class="carousel-control-next"
              type="button"
              data-bs-target="#carouselExample"
              data-bs-slide="next"
            >
              <span
                class="carousel-control-next-icon"
                aria-hidden="true"
              ></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      </div>

      <!-- 사진 오른쪽 정보 부분 -->
      <div class="col-6 mt-3">
        <p class="text-secondary">카테고리 : 의류/신발</p>
        <h4 class="mt-2">{{ post.title }}</h4>
        <h2 class="my-2">가격 : {{ price }} 원</h2>
        <div class="row mt-3">
          <div class="col-7 p-0">
            <p class="ms-3 mb-0 text-secondary">
              제품일련번호 &middot {{ post.productName }}
            </p>
          </div>
          <div class="col-5 text-end p-0">
            <RouterLink class="text-decoration-none" to="/price"
              ><p class="text-dark me-2 mb-1">
                이 상품 시세 조회하러 가기
              </p></RouterLink
            >
          </div>
        </div>

        <hr class="p-0 mt-0" />

        <div class="row mb-3">
          <div v-if="postingDate" class="col-5 ms-2">
            {{ postingDate }} &middot 조회수 20 &middot 찜 10
          </div>
          <div class="col-6 text-end ms-4">
            <RouterLink class="text-dark text-decoration-none" to="/fraud"
              ><img
                class="me-2"
                src="/images/fraudImg.jpg"
                style="width: 18px"
              />사기 조회</RouterLink
            >
          </div>
        </div>
        <div class="row">
          <div class="col-4 text-center">
            <p class="text-secondary mb-2">물품 상태</p>
            <h5 v-if="productStatus">{{ productStatus }}</h5>
          </div>
          <div class="col-4 text-center">
            <p class="text-secondary mb-2">거래 방법</p>
            <h5 v-if="deliveryMethod">{{ deliveryMethod }}</h5>
          </div>
          <div class="col-4 text-center">
            <p class="text-secondary mb-2">배송비</p>
            <h5 v-if="deliveryFee">{{ deliveryFee }}</h5>
          </div>
        </div>

        <hr class="mb-0" />

        <div class="container mt-4">
          <div class="row">
            <div class="col-md-3">
              <button
                @click="addFavorite"
                class="btn btn-outline-danger w-100"
                :class="{ active: isFavorite }"
                type="button"
              >
                찜하기
              </button>
            </div>
            <!-- 채팅하기 버튼 및 오른쪽 채팅창 부분 *24.02.05 고훈 ================================================================= -->
            <div class="col-md-9">
              <button
                class="btn btn-dark w-100"
                type="button"
                data-bs-toggle="offcanvas"
                data-bs-target="#offcanvasScrolling"
                aria-controls="offcanvasScrolling"
              >
                채팅하기
              </button>

              <div
                class="offcanvas offcanvas-end"
                data-bs-scroll="true"
                data-bs-backdrop="false"
                tabindex="-1"
                id="offcanvasScrolling"
                aria-labelledby="offcanvasScrollingLabel"
                style="width: 500px"
              >
                <!-- 판매자 이름 및 x 버튼 헤더 -->
                <div class="offcanvas-header pt-3 pb-0">
                  <div class="row w-100">
                    <div class="col-4"></div>
                    <div class="col-4">
                      <h5 class="offcanvas-title" id="offcanvasScrollingLabel">
                        판매자 이름
                      </h5>
                    </div>
                    <div class="col-4 text-end mt-1">
                      <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="offcanvas"
                        aria-label="Close"
                      ></button>
                    </div>
                  </div>
                </div>

                <hr class="mt-2 mb-2" />

                <!-- 사진 및 물품 가격  표시 부분 -->
                <div class="row m-1">
                  <div class="col-2 ps-2 ps-0">
                    <img
                      src="/images/13.jpg"
                      class="rounded-1"
                      style="width: 60px; height: 60px"
                    />
                  </div>
                  <div class="col-5 ps-0 mt-1">
                    <p class="mb-1">중고 같은 새거 팝니다</p>
                    <p class="mb-0">145,000 원</p>
                  </div>
                  <div class="col-5 p-0 mt-4">
                    <button class="btn btn-secondary me-2">예약하기</button>
                    <button class="btn btn-danger">신고하기</button>
                  </div>
                </div>

                <hr class="mt-1 mb-1" />

                <!-- 채팅 내용 부분 -->
                <div class="offcanvas-body p-3">
                  <div
                    class="container bg-dark-subtle pt-3 px-4"
                    style="height: 500px; overflow-y: scroll"
                  >
                    <!-- 상대방 프로필과 상대방 채팅 내용 부분 -->
                    <div class="row mb-3">
                      <div class="col-1 px-0">
                        <img
                          src="/images/11111111111.jpg"
                          class="rounded-circle"
                          style="width: 35px; height: 35px"
                        />
                      </div>
                      <div class="col-10 ps-0 mt-0">
                        <div class="d-inline-flex p-2 ms-2 bg-white rounded">
                          안녕하세요
                        </div>
                        <div class="d-inline-flex ms-2">
                          <p class="mb-0" style="font-size: 10px">오후 5:32</p>
                        </div>
                      </div>
                    </div>

                    <!-- 상대방 프로필과 상대방 채팅 내용 부분 -->
                    <div class="row mb-3">
                      <div class="col-1 px-0">
                        <img
                          src="/images/11111111111.jpg"
                          class="rounded-circle"
                          style="width: 35px; height: 35px"
                        />
                      </div>
                      <div class="col-10 mt-0 ps-0">
                        <div class="d-inline-flex p-2 ms-2 bg-white rounded">
                          물건 아직 있나요??
                        </div>
                        <div class="d-inline-flex ms-2">
                          <p class="mb-0" style="font-size: 10px">오후 5:32</p>
                        </div>
                      </div>
                    </div>

                    <!-- 내 채팅 내용 부분 -->
                    <div class="row mb-3">
                      <div class="col-12 d-flex justify-content-end">
                        <div class="d-inline-flex ms-2">
                          <p class="mb-0 mt-4 me-2" style="font-size: 10px">
                            오후 5:32
                          </p>
                        </div>
                        <div class="d-inline-flex p-2 bg-white rounded">
                          아직 있습니다
                        </div>
                      </div>
                    </div>

                    <!-- 내 채팅 내용 부분 -->
                    <div class="row mb-3">
                      <div class="col-12 d-flex justify-content-end">
                        <div class="d-inline-flex ms-2">
                          <p class="mb-0 mt-4 me-2" style="font-size: 10px">
                            오후 5:32
                          </p>
                        </div>
                        <div class="d-inline-flex p-2 bg-white rounded">
                          구매하실 건가요??
                        </div>
                      </div>
                    </div>

                    <!-- 내 채팅 내용 부분 -->
                    <div class="row mb-3">
                      <div class="col-12 d-flex justify-content-end">
                        <div class="d-inline-flex ms-2">
                          <p class="mb-0 mt-4 me-2" style="font-size: 10px">
                            오후 5:32
                          </p>
                        </div>
                        <div class="d-inline-flex p-2 bg-white rounded">
                          구매 결정 하신 경우 예약 잡아주시면 됩니다. 직거래
                          택배거래 모두 가능합니다
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- 채팅 입력 창 -->
                  <div class="row">
                    <textarea
                      @keyup.enter="sendMessage"
                      v-model="message"
                      type="text"
                      class="border rounded bg-light mt-2 ms-3"
                      style="height: 100px; width: 93%"
                    ></textarea>
                  </div>
                  <div class="d-flex justify-content-end mt-2 me-2">
                    <button
                      @click="sendMessage"
                      class="btn btn-secondary text-end"
                    >
                      작성하기
                    </button>
                  </div>
                  <!-- 채팅하기 버튼 및 오른쪽 채팅창 부분 종료 ================================================================= -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <hr class="my-5" />

    <div class="row">
      <!-- 상세 물품 정보 -->
      <div class="col-6 my-0">
        <div class="p-3 bg-light text-dark text-center">
          <h5>거래 전 주의 사항</h5>
          <p class="my-0" style="font-size: 12px">
            판매자가 별도의 메신저로 결제링크를 보내거나 직거래(직접송금)을
            유도하는 경우 사기일 가능성이 높으니 거래를 자제해 주세요
          </p>
        </div>
        <p v-if="post" class="my-5" style="white-space: pre-line">
          {{ post.description }}
        </p>
      </div>
      <!-- 판매자 정보 -->
      <div class="col-6">판매자 간단 정보</div>
    </div>
  </div>
</template>

<script setup>
import { instance } from '@/common/axios/axiosInstance';
import { onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const { productIdx, price, postingDate } = history.state;
const post = ref();
const productStatus = ref('');
const deliveryMethod = ref('');
const deliveryFee = ref('');
const isFavorite = ref(false);
const message = ref('');

// 게시글의 정보 db 에서 받아오는 매서드
const fetchDetail = async () => {
  try {
    const response = await instance.get('/product/' + productIdx);
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

onMounted(async () => {
  // DB에서 정보 추출 ==========================================================================================
  post.value = await fetchDetail();
  // DB에서 정보 추출 종료 =====================================================================================

  //
  //
  // ====== enum 선택 옵션 값들 처리 ===========================================================================
  // 물품 상태
  if (post.value.productStatus == 'EXCELLENT') {
    productStatus.value = '최상';
  } else if (post.value.productStatus == 'GOOD') {
    productStatus.value = '상';
  } else if (post.value.productStatus == 'FAIR') {
    productStatus.value = '중';
  } else if (post.value.productStatus == 'POOR') {
    productStatus.value = '하';
  } else if (post.value.productStatus == 'VERY_POOR') {
    productStatus.value = '최하';
  }

  // 배송방법
  if (post.value.deliveryMethod == 'SHIPPING_SERVICE') {
    deliveryMethod.value = '택배거래';
  } else if (post.value.deliveryMethod == 'DIRECT_DEAL') {
    deliveryMethod.value = '직거래';
  }

  // 배송비 포함 여부
  if (post.value.deliveryFee == 'INCLUDING_DELIVERY_FEE') {
    deliveryFee.value = '포함';
  } else if (post.value.deliveryFee == 'NOT_INCLUDING_DELIVERY_FEE') {
    deliveryFee.value = '미포함';
  }
  // ====== enum 선택 옵션 값들 처리 종료 ===========================================================================
});

//
// ====== 찜하기 버튼 처리 ==========================================================================================
// 페이지 접속한 직후 찜 했는지 여부 확인
const fetchIsFavorite = async () => {
  try {
    const response = await instance.get('user/product/favorite');
    console.log(response.data);
    response.data.map(x => {
      if (x.productIdx == productIdx) {
        isFavorite.value = true;
        return;
      }
    });
  } catch (error) {
    console.error(error);
  }
};
fetchIsFavorite();

// 찜하기 버튼을 누른 상황 처리
// 찜 추가 하는 매서드 선언
const fetchFavoriteAdd = async () => {
  try {
    const response = await instance.post(
      '/user/product/' + productIdx + '/favorite',
    );
    console.log(response);
    isFavorite.value = true;
  } catch (error) {
    console.error(error);
  }
};

// 찜 삭제 하는 매서드 선언
const fetchFavoriteDelete = async () => {
  try {
    const response = await instance.delete(
      '/user/product/' + productIdx + '/favorite',
    );
    console.log(response);
    isFavorite.value = false;
  } catch (error) {
    console.error(error);
    console.error(error.request);
  }
};

// 찜 버튼 클릭시 작동되는 매서드
const addFavorite = () => {
  // accessToken의 존재 여부로 회원인지 아닌지 판별
  if (sessionStorage.getItem('accessToken')) {
    // 회원이지만 찜버튼을 누르지 않은 상태
    if (!isFavorite.value) {
      fetchFavoriteAdd();
    } else if (isFavorite.value) {
      fetchFavoriteDelete();
    }
  } else {
    alert('회원만 찜 가능');
    router.push({ name: 'Signin' });
  }
};
// ====== 찜하기 버튼 처리 종료 ==========================================================================================

// 채팅 창에서 엔터 or 전송 버튼 클릭시 매서드
const sendMessage = () => {
  console.log('전송');
  message.value = '';
};
</script>

<style lang="scss" scoped></style>
