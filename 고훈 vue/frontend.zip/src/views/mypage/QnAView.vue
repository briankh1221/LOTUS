<template>
  <div class="container text-center"></div>
  <div class="row">
    <!-- 판매중 예약중 판매완료 헤더 -->
    <div class="container text-center mt-3 mb-5">
      <h2>질문 관리</h2>
      <hr />
    </div>
    <div class="row my-3">
      <div class="col-3"><p class="ms-3 my-0">내가 한 질문 목록</p></div>
      <div class="col-9 text-end">
        <button class="btn btn-outline-secondary rounded-5 mx-1">
          질문 작성
        </button>
      </div>
    </div>

    <!-- 선택한 조건 게시물 목록 -->
    <div class="row mx-2 mb-3">
      <div class="col-12 bg-light rounded-1">
        <div class="row">
          <div class="col-2 p-1">
            <img
              src="/images/11.jpg"
              class="rounded"
              style="width: 100px; height: 100px"
            />
          </div>
          <div class="col-3 p-2">
            <p class="mt-3">중고 같은 새물품</p>
            <p>134000 원</p>
          </div>
          <div class="col-7 border rounded">
            <span class="badge text-bg-secondary mt-2">받은 후기</span>
            <p>
              감사합니다 <br />
              안녕하세요
            </p>
          </div>
        </div>
      </div>
    </div>

    <div class="row mx-2 mb-3">
      <div class="col-12 bg-light rounded-1">
        <div class="row">
          <div class="col-2 p-1">
            <img
              src="/images/13.jpg"
              class="rounded"
              style="width: 100px; height: 100px"
            />
          </div>
          <div class="col-3 p-2">
            <p class="mt-3">주운 물건</p>
            <p>34000 원</p>
          </div>
          <div class="col-7 border rounded">
            <span class="badge text-bg-secondary mt-2">쓴후기</span>
            <p>
              주운물건 입니다 <br />
              안녕하세요
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const isHover = ref({});

// 클릭시 페이지 이동 메서드 부분 ===================================================================================

const goDetailPage = () => {};

// 클릭시 페이지 이동 메서드 부분 종료 ==============================================================================
</script>

<style lang="scss" scoped></style>
