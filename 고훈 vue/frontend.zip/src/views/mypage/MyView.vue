<template>
  <div class="container text-center"></div>
  <div class="row">
    <!-- 신뢰 지수 및 각종 내역 div -->
    <div class="row border rounded-2" style="width: 100%; height: 200px">
      <div class="row p-0">
        <div class="col-4 border text-center pt-4">
          <div class="row text-center pt-2">
            <div class="col-5 text-end pe-4">
              <img
                src="/images/11111111111.jpg"
                class="rounded-circle"
                style="width: 50px; height: 50px"
              />
            </div>
            <div class="col-7 mt-2 p-0 text-start">
              <p class="fs-5">권지현 님</p>
            </div>
          </div>
          <div class="row mb-2 mt-2">
            <div class="col-5 text-start ms-3">
              <p class="fs-6 mb-0" style="color: darkgreen">신뢰 지수 40</p>
            </div>
            <div class="col-6 text-end me-2">
              <p class="fs-6 mb-0 me-2">100</p>
            </div>
          </div>

          <div
            class="progress mx-3"
            role="progressbar"
            aria-label="Basic example"
            aria-valuenow="0"
            aria-valuemin="0"
            aria-valuemax="100"
            style="height: 10px"
          >
            <div
              class="progress-bar"
              style="
                background: linear-gradient(
                  to right,
                  rgb(105, 236, 164),
                  rgb(4, 119, 61)
                );
                width: 40%;
              "
            ></div>
          </div>
        </div>
        <div class="col-8">
          <div class="row text-center">
            <div class="col-4 mt-5">
              <p class="fs-5 mt-2 mb-0">판매내역</p>
              <hr class="mt-0 mx-5" />
              <p class="fs-4">0</p>
            </div>
            <div class="col-4 mt-5">
              <p class="fs-5 mt-2 mb-0">구매내역</p>
              <hr class="mt-0 mx-5" />
              <p class="fs-4">0</p>
            </div>
            <div class="col-4 mt-5">
              <p class="fs-5 mt-2 mb-0">리뷰내역</p>
              <hr class="mt-0 mx-5" />
              <p class="fs-4">0</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 판매중 예약중 판매완료 헤더 -->
    <div class="row my-4">
      <div class="col-3"><p class="ms-3 my-0">0 개의 상품</p></div>
      <div class="col-9 text-end">
        <button class="btn btn-outline-secondary rounded-5 mx-1 active">
          전체
        </button>
        <button class="btn btn-outline-secondary rounded-5 mx-1">판매중</button>
        <button class="btn btn-outline-secondary rounded-5 mx-1">예약중</button>
        <button class="btn btn-outline-secondary rounded-5 mx-1">
          판매완료
        </button>
      </div>
    </div>

    <!-- 선택한 조건 게시물 목록 -->
    <div class="row">
      <div
        v-for="index in 8"
        :key="index"
        class="col-2 mb-4"
        @click="goDetailPage"
      >
        <div
          class="card"
          style="width: 100%"
          @mouseover="setHover(post.productIdx, true)"
          @mouseleave="setHover(post.productIdx, false)"
        >
          <img
            src="/images/11.jpg"
            class="card-img-top"
            style="width: 100%; height: 150px; object-fit: cover"
          />
          <div class="card-body pb-0">
            <p class="card-title text-secondary fs-6 mb-0">제목입니다</p>
            <div class="row">
              <div class="col-12 mb-1">
                <p class="card-text" style="font-weight: 800; font-size: 14px">
                  2350000 원
                </p>
              </div>
            </div>
            <div class="row text-start mt-2">
              <p class="text-secondary mb-3" style="font-size: 12px">
                12시간 전
              </p>
            </div>
            <div class="row justify-content-center">
              <span class="badge text-bg-light border mb-2 w-75">판매중</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const isHover = ref({});

const setHover = (idx, value) => {
  isHover.value[idx] = value;
};

// 클릭시 페이지 이동 메서드 부분 ===================================================================================

const goDetailPage = () => {};

// 클릭시 페이지 이동 메서드 부분 종료 ==============================================================================
</script>

<style lang="scss" scoped></style>
