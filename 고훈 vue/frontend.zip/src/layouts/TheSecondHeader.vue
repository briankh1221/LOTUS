<template>
  <nav class="nav">
    <div class="btn-group">
      <button
        type="button"
        class="btn btn-secondary dropdown-toggle"
        data-bs-toggle="dropdown"
        data-bs-display="static"
        aria-expanded="false"
      >
        카테고리
      </button>
      <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-start">
        <li><button class="dropdown-item" type="button">Action</button></li>
        <li>
          <button class="dropdown-item" type="button">Another action</button>
        </li>
        <li>
          <button class="dropdown-item" type="button">
            Something else here
          </button>
        </li>
      </ul>
    </div>

    <RouterLink class="nav-link" to="/fraud">사기조회</RouterLink>
    <RouterLink class="nav-link" to="/price">시세조회</RouterLink>
    <a class="nav-link" href="#">찜한상품</a>
  </nav>
</template>

<script setup></script>

<style lang="scss" scoped></style>
