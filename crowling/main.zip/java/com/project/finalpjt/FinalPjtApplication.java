package com.project.finalpjt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalPjtApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalPjtApplication.class, args);
    }

}
