package com.project.finalpjt.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Controller
public class HomeController2 {
    @GetMapping("/2")
    @ResponseBody
    public List<String> home2() throws IOException {

        // 중고나라 사기 이력 확인하기

        List<String> command = new ArrayList<>();

        command.add("python");
        command.add("D:/kdigital2307/SpringBoot/projects/final/finalPjt/src/main/resources/templates/python/test2.py");
        command.add("account_number"); // kakao_id, account_number, phone_number, email
        command.add("3333057373650");
        ProcessBuilder processBuilder = new ProcessBuilder(command);
        processBuilder.environment().put("PYTHONIOENCODING", "utf-8"); // 인코딩 설정
        Process process2 = processBuilder.start();
        InputStream inputStream2 = process2.getInputStream();
        BufferedReader reader2 = new BufferedReader(new InputStreamReader(inputStream2, "UTF-8"));

        String line;
        List<String> list = new ArrayList<>();
        while((line = reader2.readLine()) != null) {
            list.add(line);
        }
        System.out.println(list);

        // 1. 오류 메시지 출력
        InputStream errorStream2 = process2.getErrorStream();
        BufferedReader errorReader2 = new BufferedReader(new InputStreamReader(errorStream2));

        String errorLine2;
        while ((errorLine2 = errorReader2.readLine()) != null) {
            System.out.println(errorLine2);
        }

//        // 2. 프로세스 종료 대기
//        int exitCode = process.waitFor();
//        System.out.println("종료 코드: " + exitCode);
//
//        // 3. 프로세스 강제 종료
//        process.destroy();

        // 4. 종료 코드 확인
        int exitCode2 = process2.exitValue();
        System.out.println("외부 프로그램 종료 코드: " + exitCode2);

        return list;
    }
}
