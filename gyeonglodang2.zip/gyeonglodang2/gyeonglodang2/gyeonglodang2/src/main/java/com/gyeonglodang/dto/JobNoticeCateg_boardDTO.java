package com.gyeonglodang.dto;

import lombok.Data;

@Data
public class JobNoticeCateg_boardDTO {
      
	 private String jobNoticeCateg_idx;
     private int companyIdx;
     private String noticeControl_idx;
     private String jobNoticeCateg_title;
     private String jobNoticeCateg_postingDate;
     private String jobNoticeCateg_operation;
     private String jobNoticeCateg_file_name;
     private String jobNoticeCateg_categ;
     private String jobNoticeCateg_content;
     private String jobNoticeCateg_regi;

}