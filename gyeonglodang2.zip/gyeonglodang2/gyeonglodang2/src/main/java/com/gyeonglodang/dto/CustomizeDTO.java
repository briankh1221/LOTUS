package com.gyeonglodang.dto;

import lombok.Data;

@Data
public class CustomizeDTO {
	int idx,gonggoidx,companyIdx;
	String name,fieldidx,column1,column2,column3,part,scode;
}
