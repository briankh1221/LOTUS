package com.gyeonglodang.dto;

import lombok.Data;

@Data
public class QnaFileDTO {
	
	private int qna_fileupload_idx;
	private int qna_board_idx;
	private String qna_file_path;
		
	}
	
