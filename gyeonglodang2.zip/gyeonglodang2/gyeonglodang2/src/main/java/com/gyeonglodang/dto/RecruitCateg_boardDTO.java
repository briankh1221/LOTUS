package com.gyeonglodang.dto;

import lombok.Data;

@Data
public class RecruitCateg_boardDTO {

	private String recruitCateg_idx;
	private int companyIdx;
	private String noticeControl_idx;
	private String recruitCateg_order;
	private String recruitCateg_categ;
	private String recruitCateg_number;
	private String recruitCateg_testID;
	private String recruitCateg_status_change;
	private String recruitCateg_show;

}
