package com.gyeonglodang.dto;

import lombok.Data;

@Data
public class FileUploadDTO {

	private String idx;
	private String noticeControl_idx;
	private String fileUpload_idx;
	private String fileName;
	private String filePath;
	
}
