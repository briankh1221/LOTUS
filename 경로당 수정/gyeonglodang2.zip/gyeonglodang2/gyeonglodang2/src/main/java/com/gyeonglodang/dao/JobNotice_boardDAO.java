package com.gyeonglodang.dao;

import org.springframework.stereotype.Repository;

@Repository
public class JobNotice_boardDAO {

	public String ncSearchList() {

		
		return null;
	}
}
