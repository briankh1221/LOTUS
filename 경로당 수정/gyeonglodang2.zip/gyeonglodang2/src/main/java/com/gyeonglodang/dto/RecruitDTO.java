package com.gyeonglodang.dto;

import lombok.Data;

@Data
public class RecruitDTO {
	int idx;
	String email,password,scode;
}
