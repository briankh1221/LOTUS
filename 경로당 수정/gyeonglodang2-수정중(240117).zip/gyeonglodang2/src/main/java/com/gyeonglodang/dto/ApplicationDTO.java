package com.gyeonglodang.dto;

public class ApplicationDTO {
	private int application_idx;
	private int applicant_idx;
}
