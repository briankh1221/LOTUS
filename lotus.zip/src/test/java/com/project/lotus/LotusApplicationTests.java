package com.project.lotus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LotusApplicationTests {

    @Test
    void contextLoads() {
    }

}
