package com.project.lotus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LotusApplication {

    public static void main(String[] args) {
        SpringApplication.run(LotusApplication.class, args);
    }

}
