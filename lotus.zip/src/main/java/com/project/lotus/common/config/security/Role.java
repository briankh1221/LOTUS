package com.project.lotus.common.config.security;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
