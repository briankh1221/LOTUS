package com.project.websoket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsoketApplicationTests {

    @Test
    void contextLoads() {
    }

}
