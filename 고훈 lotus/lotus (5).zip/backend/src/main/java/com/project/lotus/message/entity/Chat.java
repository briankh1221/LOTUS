package com.project.lotus.message.entity;

public class Chat {
}
