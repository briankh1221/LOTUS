package com.project.lotus.common.enums;

public enum DeliveryMethod {

    // 택배 거래 *24.01.19 jihyun
    SHIPPING_SERVICE,

    // 직거래 *24.01.19 jihyun
    DIRECT_DEAL
}
