package com.project.lotus.product.dto;

import com.project.lotus.common.enums.*;
import com.project.lotus.product.entity.Product;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

public class ProductDto {

    @Builder
    @Setter
    @Getter
    public static class Request {

        // 상품 카테고리 *24.01.19 jihyun
        private CategoryName categoryName;

        // 상품명 *24.01.19 jihyun
        private String productName;

        // 글 제목 *24.01.24 jihyun
        private String title;

        // 상품 설명 *24.01.19 jihyun
        private String description;

        // 택배비 포함 여부 *24.01.19 jihyun
        private DeliveryFee deliveryFee;

        // 상품 가격 *24.01.19 jihyun
        private String price;

        // 상품 이미지 *24.01.19 jihyun
        private String images;

        // 상품 상태 *24.01.19 jihyun
        private ProductStatus productStatus;

        // 거래 방법 *24.01.19 jihyun
        private DeliveryMethod deliveryMethod;

        // 거래 가능한 주소 *24.01.19 jihyun
        private String address;

        // 거래 상태 *24.01.19 jihyun
        private TransactionStatus transactionStatus;

        // ProductForm -> ProductDto로 변환 *24.01.26 jihyun
        public static ProductDto.Request from (ProductForm.Request productForm) {

            return Request.builder()
                    .categoryName(productForm.getCategoryName())
                    .productName(productForm.getProductName())
                    .title(productForm.getTitle())
                    .description(productForm.getDescription())
                    .deliveryFee(productForm.getDeliveryFee())
                    .price(productForm.getPrice())
                    .images(productForm.getImages().toString())
                    .productStatus(productForm.getProductStatus())
                    .deliveryMethod(productForm.getDeliveryMethod())
                    .address(productForm.getAddress())
                    .transactionStatus(productForm.getTransactionStatus())
                    .build();
        }
    }

    @Builder
    @Getter
    public static class Response {

        // 상품 인덱스 *24.01.24 jihyun
        private Long productIdx;

        private CategoryName categoryName;

        private String productName;

        private String title;

        private String description;

        private DeliveryFee deliveryFee;

        private String price;

        private String images;

        private ProductStatus productStatus;

        private DeliveryMethod deliveryMethod;

        private String address;

        private TransactionStatus transactionStatus;

        // 상품 등록 생성일 *24.02.01 jihyun
        private LocalDateTime postingDate;

        // Product(Entity) -> ProductDto.Response로 변환 *24.01.24 jihyun
        public static ProductDto.Response from (Product product) {

            return Response.builder()
                    .productIdx(product.getProductIdx())
                    .categoryName(product.getCategoryName())
                    .productName(product.getProductName())
                    .title(product.getTitle())
                    .description(product.getDescription())
                    .deliveryFee(product.getDeliveryFee())
                    .price(product.getPrice())
                    .images(product.getImages())
                    .productStatus(product.getProductStatus())
                    .deliveryMethod(product.getDeliveryMethod())
                    .address(product.getAddress())
                    .postingDate(product.getPostingDate())
                    .transactionStatus(product.getTransactionStatus())
                    .build();
        }
    }
}
