package com.project.lotus.product.controller;

import com.project.lotus.common.enums.CategoryName;
import com.project.lotus.product.dto.ProductDto;
import com.project.lotus.product.service.impl.ProductServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RequestMapping("/product")
@RestController
@RequiredArgsConstructor
public class ProductController {

    private final ProductServiceImpl productServiceImpl;

    // 상품 상세 정보 조회 *24.01.25 jihyun
    @GetMapping("/{productIdx}")
    public ResponseEntity<ProductDto.Response> productDetails(
            @PathVariable Long productIdx) {

        ProductDto.Response response = productServiceImpl.findProductDetails(productIdx);

        return ResponseEntity.status(OK).body(response);
    }

    // 카테고리별 상품 목록 조회 *24.01.25 jihyun
    @GetMapping("/category-list/{categoryName}")
    public ResponseEntity<List<ProductDto.Response>> productList(
            @PathVariable CategoryName categoryName) {

        List<ProductDto.Response> productDtoList = productServiceImpl.findProductList(categoryName);

        return ResponseEntity.status(OK).body(productDtoList);
    }

    // 최신 상품 조회 *24.01.25 jihyun
    @GetMapping("/recent-list")
    public ResponseEntity<List<ProductDto.Response>> recentProductList() {

        List<ProductDto.Response> productDtoList = productServiceImpl.findRecentProductList();

        return ResponseEntity.status(OK).body(productDtoList);
    }

    // 베스트 찜 상품 조회 *24.02.02 jihyun
    @GetMapping("/best-list")
    public ResponseEntity<List<Long>> bestProductList() {

        List<Long> productIdxList = productServiceImpl.findBestProductList();

        return ResponseEntity.status(OK).body(productIdxList);
    }
}
