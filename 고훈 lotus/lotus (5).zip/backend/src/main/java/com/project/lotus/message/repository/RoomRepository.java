package com.project.lotus.message.repository;

import com.project.lotus.message.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RoomRepository extends JpaRepository<Room, Long> {

    Optional<Room> findByBuyer_EmailAndProduct_ProductIdx(String buyerEmail, Long productIdx);
    Optional<List<Room>> findByBuyer_EmailOrProduct_User_Email(String buyerEmail, String productUserEmail);



}
