package com.project.lotus.message.service;

import com.project.lotus.auth.entity.User;
import com.project.lotus.auth.repository.UserRepository;
import com.project.lotus.common.exception.CustomException;
import com.project.lotus.message.dto.ChatDto;
import com.project.lotus.message.dto.RoomDto;
import com.project.lotus.message.entity.Room;
import com.project.lotus.message.repository.RoomRepository;
import com.project.lotus.product.entity.Product;
import com.project.lotus.product.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ChatService {

    @Value("${file.dir}")
    private String fileDir;

    private final RoomRepository roomRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;


    public RoomDto.Response createRoom (RoomDto.Request roomDto) {

        Room room = new Room();

        try {
            room = roomRepository.findByBuyer_EmailAndProduct_ProductIdx(roomDto.getBuyerEmail(), roomDto.getProductIdx())
                    .orElseThrow();

            System.out.println("ChatService - createRoom 매서드 - try 문 room 출력 : " + room);


        } catch (Exception e) {

            User buyer = userRepository.findByEmail(roomDto.getBuyerEmail()).orElseThrow();

            Product product = productRepository.findByProductIdx(roomDto.getProductIdx()).orElseThrow();

            System.out.println("ChatService - createRoom 매서드 - catch 문 진입");

            room = roomRepository.save(Room.builder()
                    .buyer(buyer)
                    .product(product)
                    .build());
        }

        return RoomDto.Response.from(room);
    }

    public String saveFile(ChatDto chatDto) {

        // 판매자, 구매자, 상품번호 합하여 고유 텍스트 파일명 저장 *24.01.26 jihyun
        String filePath = fileDir + "/" + chatDto.getBuyerEmail() + "_" + chatDto.getProductIdx() + ".txt";

        try {
            FileWriter fileWriter = new FileWriter(filePath, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            String writer;
            if(chatDto.getIsBuyerEmail()) {
                writer = "Buyer";
            } else {
                writer = "Seller";

            }

            String formattedMessage = String.format("[%s]%s:%s",
                    LocalDateTime.now(), writer, chatDto.getMessage());

            bufferedWriter.write(formattedMessage);
            bufferedWriter.newLine();

            bufferedWriter.close();
            fileWriter.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return filePath;
    }

    public List<RoomDto.Response> findRoomList(String email) {
        System.out.println("ChatService - findRoomList - email 출력 : " + email);

        List<Room> roomList = roomRepository.findByBuyer_EmailOrProduct_User_Email(email, email).orElseThrow();

        List<RoomDto.Response> roomDtoList = new ArrayList<>();

        for(Room room : roomList) {
            roomDtoList.add(RoomDto.Response.from(room));
        }

        return roomDtoList;
    }


}
