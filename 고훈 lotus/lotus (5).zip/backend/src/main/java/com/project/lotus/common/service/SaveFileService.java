package com.project.lotus.common.service;

import com.project.lotus.auth.entity.User;
import com.project.lotus.message.dto.ChatDto;
import com.project.lotus.message.dto.MessageDto;
import com.project.lotus.message.entity.Chat;
import com.project.lotus.product.entity.Product;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

@Service
public class SaveFileService {

    @Value("${file.dir}")
    private String fileDir;

    public String saveFile(ChatDto chatDto) {

        // 판매자, 구매자, 상품번호 합하여 고유 텍스트 파일명 저장 *24.01.26 jihyun
        String filePath = fileDir + "/" + chatDto.getBuyerEmail() + "_" + chatDto.getProductIdx() + ".txt";

        try {
            FileWriter fileWriter = new FileWriter(filePath, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            String writer;
            if(chatDto.getIsBuyerEmail()) {
                writer = "Buyer";
            } else {
                writer = "Seller";

            }

            String formattedMessage = String.format("[%s]%s:%s",
                    LocalDateTime.now(), writer, chatDto.getMessage());

            bufferedWriter.write(chatDto.getMessage());
            bufferedWriter.newLine();

            bufferedWriter.close();
            fileWriter.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return filePath;
    }
}
