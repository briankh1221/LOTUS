package com.project.lotus.message.dto;

import com.project.lotus.auth.entity.User;
import com.project.lotus.message.entity.Room;
import com.project.lotus.product.entity.Product;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

public class RoomDto {

    @Data
    @Builder
    @ToString
    public static class Request {

        private String buyerEmail;

        private Long productIdx;

    }

    @Data
    @Builder
    @ToString
    public static class Response {

        private Long roomIdx;

        private User buyer;

        private Product product;

        public static RoomDto.Response from (Room room) {

            return Response.builder()
                    .roomIdx(room.getRoomIdx())
                    .buyer(room.getBuyer())
                    .product(room.getProduct())
                    .build();
        }

    }
}
