package com.project.lotus.admin.service.impl;

import com.project.lotus.admin.dto.QnaReplyDto;
import com.project.lotus.admin.dto.QnaReplyForm;
import com.project.lotus.admin.entity.QnaReply;
import com.project.lotus.admin.repository.QnaReplyRepository;
import com.project.lotus.admin.service.AdminService;
import com.project.lotus.auth.dto.AdminsignupForm;
import com.project.lotus.auth.dto.SignupDto;
import com.project.lotus.auth.entity.User;
import com.project.lotus.auth.repository.UserRepository;
import com.project.lotus.common.config.security.TokenProvider;
import com.project.lotus.common.exception.CustomException;
import com.project.lotus.common.service.UploadService;
import com.project.lotus.user.entity.Qna;
import com.project.lotus.user.repository.QnaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

import static com.project.lotus.common.enums.Role.ROLE_USER;
import static com.project.lotus.common.exception.ErrorCode.*;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final TokenProvider tokenProvider;
    private final PasswordEncoder passwordEncoder;

    private final UploadService uploadService;

    // Repository *24.02.01 jihyun
    private final UserRepository userRepository;
    private final QnaRepository qnaRepository;
    private final QnaReplyRepository qnaReplyRepository;

    // 관리자 (마이 페이지) 정보 조회 *24.02.03 jihyun
    @Override
    public SignupDto.Response findProfile(String accessToken) {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        return SignupDto.Response.from(user);
    }

    // 관리자 (마이 페이지) 정보 수정 *24.02.03 jihyun
    @Override
    public void modifyProfile(String accessToken, AdminsignupForm.Request adminSignupForm,
                              MultipartFile image) throws IOException {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        SignupDto.Request signupDto = SignupDto.Request.from(adminSignupForm);

        if (image != null && !image.isEmpty()) {
            String imagePath = uploadService.fileUpload(image);
            signupDto.setImage(imagePath);
        }

        user.modifyUser(signupDto, passwordEncoder.encode(signupDto.getPassword()));

        userRepository.save(user);
    }

    // 관리자 Q&A 답변 등록 *24.02.01 jihyun
    @Override
    public void addReply(String accessToken, Long qnaIdx, QnaReplyForm.Request qnaReplyForm) {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        Qna qna = qnaRepository.findByQnaIdx(qnaIdx)
                .orElseThrow(() -> new CustomException(QNA_NOT_EXISTS));

        QnaReplyDto.Request qnaReplyDto = QnaReplyDto.Request.from(qnaReplyForm);

        qnaReplyRepository.save(QnaReply.from(qnaReplyDto, user, qna));
    }

    // 관리자 Q&A 답변 수정 *24.02.01 jihyun
    @Override
    public void modifyReply(Long qnaReplyIdx, QnaReplyForm.Request qnaReplyForm) {

        QnaReply qnaReply = qnaReplyRepository.findByQnaReplyIdx(qnaReplyIdx)
                .orElseThrow(() -> new CustomException(QNA_REPLY_NOT_EXISTS));

        QnaReplyDto.Request qnaReplyDto = QnaReplyDto.Request.from(qnaReplyForm);

        qnaReply.modifyQnaReply(qnaReplyDto);

        qnaReplyRepository.save(qnaReply);
    }

    // 관리자 Q&A 답변 삭제 *24.02.01 jihyun
    @Override
    public void removeReply(Long qnaReplyIdx) {

        QnaReply qnaReply = qnaReplyRepository.findByQnaReplyIdx(qnaReplyIdx)
                .orElseThrow(() -> new CustomException(QNA_REPLY_NOT_EXISTS));

        qnaReplyRepository.delete(qnaReply);
    }
}
