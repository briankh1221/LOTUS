package com.project.lotus.message.controller;

import com.project.lotus.message.dto.ChatDto;
import com.project.lotus.message.dto.RoomDto;
import com.project.lotus.message.service.ChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RestController
@CrossOrigin
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    @MessageMapping("/{roomId}")
    @SendTo("/room/{roomId}")
    public ChatDto test(@DestinationVariable Long roomId, ChatDto chatDto) {

        System.out.println("ChatController - test 매서드");
        System.out.println("ChatController - test 매서드 - " + chatDto);

        chatService.saveFile(chatDto);

        return chatDto;
    }

    @PostMapping("/room")
    public ResponseEntity<RoomDto.Response> roomCreate(@RequestBody RoomDto.Request roomDto) {

        System.out.println("ChatController - roomCreate 매서드 - roomDto 출력 : " + roomDto);
        RoomDto.Response resoponse = chatService.createRoom(roomDto);

        return ResponseEntity.status(OK).body(resoponse);
    }

    @GetMapping("/room-list/{email}")
    public ResponseEntity<List<RoomDto.Response>> findRoomList(@PathVariable String email) {
        System.out.println("ChatController - findRoomList - email 출력 : " + email);


        List<RoomDto.Response> roomDtoList =  chatService.findRoomList(email);

        System.out.println("ChatController - findRoomList - roomDtoList 출력 : " + roomDtoList);
        return ResponseEntity.status(OK).body(roomDtoList);

    }
}
