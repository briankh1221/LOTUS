package com.project.lotus.message.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ChatDto {

    private String message;
    private String buyerEmail;
    private Long productIdx;
    private Boolean isBuyerEmail;

}
