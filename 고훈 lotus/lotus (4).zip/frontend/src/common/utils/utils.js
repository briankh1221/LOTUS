import VueJwtDecode from 'vue-jwt-decode';

const isExpired = accessToken => {
  const expiration = VueJwtDecode.decode(accessToken).exp;

  return Math.floor(Date.now() / 1000) > expiration ? true : false;
};

const getRole = accessToken => {
  const role = VueJwtDecode.decode(accessToken).role;

  return role;
};

const connect = () => {
  this.websocket = new WebSocket('ws://localhost:8081/user/chat');
  this.websocket.onerror = function (error) {
    console.log(error);
  };
  this.websocket.onclose = function (event) {
    console.log(event);
  };
};

export { isExpired, getRole, connect };
