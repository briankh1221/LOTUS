<template>
  <button
    class="btn btn-primary"
    type="button"
    data-bs-toggle="offcanvas"
    data-bs-target="#offcanvasScrolling"
    aria-controls="offcanvasScrolling"
  >
    채팅하기
  </button>

  <div
    class="offcanvas offcanvas-end"
    data-bs-scroll="true"
    data-bs-backdrop="false"
    tabindex="-1"
    id="offcanvasScrolling"
    aria-labelledby="offcanvasScrollingLabel"
    style="width: 500px"
  >
    <!-- 판매자 이름 및 x 버튼 헤더 -->
    <div class="offcanvas-header pt-3 pb-0">
      <div class="row w-100">
        <div class="col-4"></div>
        <div class="col-4">
          <h5 class="offcanvas-title" id="offcanvasScrollingLabel">
            판매자 이름
          </h5>
        </div>
        <div class="col-4 text-end mt-1">
          <button
            type="button"
            class="btn-close"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
      </div>
    </div>

    <hr class="mt-2 mb-2" />

    <!-- 사진 및 물품 가격  표시 부분 -->
    <div class="row m-1">
      <div class="col-4 ps-2 ps-0">
        <img
          src="/images/11111111111.jpg"
          class="rounded-1"
          style="width: 60px; height: 60px"
        />
      </div>
      <div class="col-8">2222</div>
    </div>

    <hr class="mt-2 mb-1" />

    <!-- 채팅 내용 부분 -->
    <div class="offcanvas-body p-3">
      <div
        class="container bg-dark-subtle pt-3 px-4"
        style="height: 500px; overflow-y: scroll"
      >
        <!-- 상대방 프로필과 상대방 채팅 내용 부분 -->
        <div class="row mb-3">
          <div class="col-1 px-0">
            <img
              src="/images/11111111111.jpg"
              class="rounded-circle"
              style="width: 35px; height: 35px"
            />
          </div>
          <div class="col-10 ps-0 mt-0">
            <div class="d-inline-flex p-2 ms-2 bg-white rounded">
              안녕하세요
            </div>
            <div class="d-inline-flex ms-2">
              <p class="mb-0" style="font-size: 10px">오후 5:32</p>
            </div>
          </div>
        </div>

        <!-- 상대방 프로필과 상대방 채팅 내용 부분 -->
        <div class="row mb-3">
          <div class="col-1 px-0">
            <img
              src="/images/11111111111.jpg"
              class="rounded-circle"
              style="width: 35px; height: 35px"
            />
          </div>
          <div class="col-10 mt-0 ps-0">
            <div class="d-inline-flex p-2 ms-2 bg-white rounded">
              물건 아직 있나요??
            </div>
            <div class="d-inline-flex ms-2">
              <p class="mb-0" style="font-size: 10px">오후 5:32</p>
            </div>
          </div>
        </div>

        <!-- 상대방 프로필과 상대방 채팅 내용 부분 -->
        <!-- <div class="row mb-3">
          <div class="col-2 ps-0">
            <img
              src="/images/11111111111.jpg"
              class="rounded-circle"
              style="width: 42px; height: 42px"
            />
          </div>
          <div class="col-10 ps-0 mt-0">
            <div class="d-inline-flex p-2 bg-white rounded">
              안녕하세요 안녕하세요 안녕하세요 안녕하세요 안녕하세요 안녕하세요
              안녕하세요
            </div>
            <div class="d-inline-flex ms-2">
              <p class="mb-0" style="font-size: 10px">오후 5:32</p>
            </div>
          </div>
        </div> -->

        <!-- 내 채팅 내용 부분 -->
        <div class="row mb-3">
          <div class="col-12 d-flex justify-content-end">
            <div class="d-inline-flex ms-2">
              <p class="mb-0 mt-4 me-2" style="font-size: 10px">오후 5:32</p>
            </div>
            <div class="d-inline-flex p-2 bg-white rounded">아직 있습니다</div>
          </div>
        </div>

        <!-- 내 채팅 내용 부분 -->
        <div class="row mb-3">
          <div class="col-12 d-flex justify-content-end">
            <div class="d-inline-flex ms-2">
              <p class="mb-0 mt-4 me-2" style="font-size: 10px">오후 5:32</p>
            </div>
            <div class="d-inline-flex p-2 bg-white rounded">
              구매하실 건가요??
            </div>
          </div>
        </div>

        <!-- 내 채팅 내용 부분 -->
        <div class="row mb-3">
          <div class="col-12 d-flex justify-content-end">
            <div class="d-inline-flex ms-2">
              <p class="mb-0 mt-4 me-2" style="font-size: 10px">오후 5:32</p>
            </div>
            <div class="d-inline-flex p-2 bg-white rounded">
              구매 결정 하신 경우 예약 잡아주시면 됩니다. 직거래 택배거래 모두
              가능합니다
            </div>
          </div>
        </div>
      </div>
      <!-- 채팅 입력 창 -->
      <div class="row">
        <textarea
          @keyup.enter="sendMessage"
          v-model="message"
          type="text"
          class="border rounded bg-light mt-2 ms-3"
          style="height: 100px; width: 93%"
        ></textarea>
      </div>
      <div class="d-flex justify-content-end mt-2 me-2">
        <button @click="sendMessage" class="btn btn-secondary text-end">
          작성하기
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const socket = new WebSocket('ws://localhost:8081/chat');

// 소켓이 열릴 시 실행되는 매서드
socket.onopen = function (event) {
  console.log('소켓이 open 되었습니다, event : ', event, event.data);

  const data = {
    productIdx: 1,
    accessToken: '329a0fj9a032f2fna3;pfn',
  };
  const frame = `SEND\ndestination:/sub\ncontent-type:application/json\n\n${JSON.stringify(data)}\x00`;
  socket.send(frame);
};

// 메세지를 받았을 때 실행되는 함수
socket.onmessage = function (event) {
  console.log('메세지를 받았습니다', event.data);
};

// 소켓이 닫혔을 때 실행 되는 함수
socket.onclose = function (event) {
  console.log('소켓이 close 되었습니다.', event.data);
};

// 소켓이 열릴 시 실행되는 매서드
socket.onerror = function (error) {
  console.log('오류가 발생했습니다 : ', error);
};

const message = ref('');

const sendMessage = () => {
  console.log('sendMessage 매서드 내부');

  socket.send({ message: 'hello' });
};
</script>

<style lang="scss" scoped></style>
