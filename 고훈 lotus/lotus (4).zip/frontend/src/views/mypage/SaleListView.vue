<template>
  <div class="container text-center"></div>
  <div class="row">
    <!-- 판매중 예약중 판매완료 헤더 -->
    <div class="container text-center mt-3 mb-5">
      <h2>판매 내역</h2>
      <hr />
    </div>
    <div class="row my-3">
      <div class="col-3"><p class="ms-3 my-0">0 개의 상품</p></div>
      <div class="col-9 text-end">
        <button class="btn btn-outline-secondary rounded-5 mx-1 active">
          전체
        </button>
        <button class="btn btn-outline-secondary rounded-5 mx-1">판매중</button>
        <button class="btn btn-outline-secondary rounded-5 mx-1">예약중</button>
        <button class="btn btn-outline-secondary rounded-5 mx-1">
          판매완료
        </button>
      </div>
    </div>

    <!-- 선택한 조건 게시물 목록 -->
    <div class="row">
      <div
        v-for="index in 3"
        :key="index"
        class="col-2 mb-4"
        @click="goDetailPage"
      >
        <div class="card" style="width: 100%">
          <img
            src="/images/11.jpg"
            class="card-img-top"
            style="width: 100%; height: 150px; object-fit: cover"
          />
          <div class="card-body pb-0">
            <p class="card-title text-secondary fs-6 mb-0">제목입니다</p>
            <div class="row">
              <div class="col-12 mb-1">
                <p class="card-text" style="font-weight: 800; font-size: 14px">
                  2350000 원
                </p>
              </div>
            </div>
            <div class="row text-start mt-2">
              <p class="text-secondary mb-3" style="font-size: 12px">
                12시간 전
              </p>
            </div>
            <div class="row justify-content-center">
              <span class="badge text-bg-light border mb-2 w-75">판매중</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const isHover = ref({});

const setHover = (idx, value) => {
  isHover.value[idx] = value;
};
// 클릭시 페이지 이동 메서드 부분 ===================================================================================

const goDetailPage = () => {};

// 클릭시 페이지 이동 메서드 부분 종료 ==============================================================================
</script>

<style lang="scss" scoped></style>
