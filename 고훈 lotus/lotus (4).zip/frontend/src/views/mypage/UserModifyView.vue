<template>
  <div class="container text-center"></div>
  <div class="row">
    <br /><br /><br />
    <div class="row justify-content-center">
      <div class="card p-0 border-0" style="width: 500px; height: 400px">
        <div class="card-body bg-body-tertiary">
          <div class="d-flex flex-column">
            <h5 class="text-center mb-5">회원 정보 수정</h5>
            <div class="row">
              <div class="col-3 h-50">
                <p class="mb-0 ms-4">ID</p>
              </div>
              <div class="col-9 h-50">
                <input
                  v-model="form.id"
                  type="text"
                  class="bg-body-tertiary border-0 mb-0 ms-0"
                  style="outline: none"
                  placeholder="아이디"
                />
                <hr class="mt-1 me-3" />
              </div>
            </div>
            <div class="row">
              <div class="col-3 h-50">
                <p class="mb-0 ms-4">비밀번호</p>
              </div>
              <div class="col-9 h-50">
                <input
                  v-model="form.password"
                  type="text"
                  class="bg-body-tertiary border-0 mb-0 ms-0"
                  style="outline: none"
                  placeholder="비밀번호"
                />
                <hr class="mt-1 me-3" />
              </div>
            </div>
            <div class="row">
              <div class="col-3 h-50">
                <p class="mb-0 ms-4">이름</p>
              </div>
              <div class="col-9 h-50">
                <input
                  v-model="form.name"
                  type="text"
                  class="bg-body-tertiary border-0 mb-0 ms-0"
                  style="outline: none"
                  placeholder="이름"
                />
                <hr class="mt-1 me-3" />
              </div>
            </div>
            <div class="row">
              <div class="col-3 h-50">
                <p class="mb-0 ms-4">이메일</p>
              </div>
              <div class="col-9 h-50">
                <input
                  v-model="form.email"
                  type="text"
                  class="bg-body-tertiary border-0 mb-0 ms-0"
                  style="outline: none"
                  placeholder="이메일"
                />
                <hr class="mt-1 me-3" />
              </div>
            </div>
            <div class="row">
              <div class="col-3 h-50">
                <p class="mb-0 ms-4">전화번호</p>
              </div>
              <div class="col-9 h-50">
                <input
                  v-model="form.phone"
                  type="text"
                  class="bg-body-tertiary border-0 mb-0 ms-0"
                  style="outline: none"
                  placeholder="전화번호"
                />
                <hr class="mt-1 me-3" />
              </div>
            </div>

            <button class="btn btn-secondary my-5 mb-1" @click="modifyMethod">
              정보 수정
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const fetchDetail = async () => {
  try {
    const response = await instance.get('/product/recent-list');
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

const form = ref({
  id: null,
  password: null,
  name: null,
  email: null,
  phone: null,
});

// 클릭시 페이지 이동 메서드 부분 ===================================================================================

const goDetailPage = () => {};

// 클릭시 페이지 이동 메서드 부분 종료 ==============================================================================
</script>

<style lang="scss" scoped></style>
