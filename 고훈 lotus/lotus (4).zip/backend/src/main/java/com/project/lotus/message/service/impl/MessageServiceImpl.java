package com.project.lotus.message.service.impl;

import com.project.lotus.auth.entity.User;
import com.project.lotus.auth.repository.UserRepository;
import com.project.lotus.common.config.security.TokenProvider;
import com.project.lotus.common.exception.CustomException;
import com.project.lotus.message.dto.MessageDto;
import com.project.lotus.message.entity.Message;
import com.project.lotus.message.repository.MessageRepository;
import com.project.lotus.message.service.MessageService;
import com.project.lotus.common.service.SaveFileService;
import com.project.lotus.product.entity.Product;
import com.project.lotus.product.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import static com.project.lotus.common.exception.ErrorCode.*;

@Service
@RequiredArgsConstructor
public class MessageServiceImpl implements MessageService {

    private final TokenProvider tokenProvider;

    private final SaveFileService saveFileService;

    // Repository *24.02.02 jihyun
    private final UserRepository userRepository;
    private final MessageRepository messageRepository;
    private final ProductRepository productRepository;

    // 메시지 보내기 *24.02.02 jihyun
    @Override
    public void addMessage(String accessToken, MessageDto.Request messageDto) {

        String email = tokenProvider.getEmail(accessToken);

        User buyer = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        Product seller = productRepository.findUserByProductIdx(messageDto.getProductIdx())
                .orElseThrow(() -> new CustomException(THE_OTHER_NOT_EXISTS));

        Product product = productRepository.findById(messageDto.getProductIdx())
                .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));


        String filePath = saveFileService.saveFile(messageDto, buyer, seller);

        // String Content에 텍스트 파일 경로 저장 *24.02.02 jihyun
        messageDto.setContent(filePath);

        messageRepository.save(Message.from(buyer, seller, product, messageDto));
    }
}
