package com.project.lotus.admin.controller;

import com.project.lotus.admin.dto.QnaReplyForm;
import com.project.lotus.admin.service.impl.AdminServiceImpl;
import com.project.lotus.auth.dto.AdminsignupForm;
import com.project.lotus.auth.dto.SignupDto;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

import static org.springframework.http.HttpStatus.*;

@RequestMapping("/admin")
@RestController
@RequiredArgsConstructor
public class AdminController {

    private final AdminServiceImpl adminServiceImpl;

    // 관리자 (마이 페이지) 정보 조회 *24.02.03 jihyun
    @GetMapping("/details")
    public ResponseEntity<SignupDto.Response> profileFind (
            @RequestHeader(name = "Authorization") String accessToken) {

        SignupDto.Response signupDto = adminServiceImpl.findProfile(accessToken);

        return ResponseEntity.status(OK).body(signupDto);
    }

    // 관리자 (마이 페이지) 정보 수정 *24.02.03 jihyun
    @PutMapping("/details")
    public ResponseEntity<Void> profileModify (
            @RequestHeader(name = "Authorization") String accessToken,
            @Valid @RequestBody AdminsignupForm.Request adminSignupForm,
            @RequestPart(value = "image", required = false) MultipartFile image) throws IOException {

        adminServiceImpl.modifyProfile(accessToken, adminSignupForm, image);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 관리자 답변 등록 *24.02.01 jihyun
    @PostMapping(value = "/qna/{qnaIdx}/qnareply")
    public ResponseEntity<Void> replyAdd(
            @RequestHeader(name = "Authorization") String accessToken,
            @PathVariable Long qnaIdx,
            @Valid QnaReplyForm.Request qnaReplyForm) {

        adminServiceImpl.addReply(accessToken, qnaIdx, qnaReplyForm);

        return ResponseEntity.status(CREATED).build();
    }

    // 관리자 답변 수정 *24.02.01 jihyun
    @PutMapping(value = "/qna/{qnaIdx}/qnareply/{qnaReplyIdx}")
    public ResponseEntity<Void> replyModify(
            @PathVariable Long qnaReplyIdx,
            @Valid QnaReplyForm.Request qnaReplyForm) {

        adminServiceImpl.modifyReply(qnaReplyIdx, qnaReplyForm);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 관리자 답변 삭제 *24.02.01 jihyun
    @DeleteMapping(value="/qna/{qnaIdx}/qnareply/{qnaReplyIdx}")
    public ResponseEntity<Void> replyRemove(
            @PathVariable Long qnaReplyIdx) {

        adminServiceImpl.removeReply(qnaReplyIdx);

        return ResponseEntity.status(NO_CONTENT).build();
    }
}
