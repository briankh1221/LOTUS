package com.project.lotus.auth.dto;


import com.project.lotus.auth.entity.User;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.web.multipart.MultipartFile;


public class SignupDto {
    @Getter @Setter
    @Builder
    public static class Request {

        // 가입자 ID *24.01.19 jihyun
        private String id;

        // 가입자 PW *24.01.19 jihyun
        private String password;

        // 가입자 이름 *24.01.19 jihyun
        private String name;

        // 가입자 휴대전화 *24.01.19 jihyun
        private String phone;

        // 가입자 이메일 *24.01.19 jihyun
        private String email;

        // 가입자 프로필 사진 (정보 수정시만 업데이트 가능함) *24.02.03 jihyun
        private String image;

        // UserSignForm.Request -> SignDto.Request로 변환 *24.01.19 jihyun
        public static SignupDto.Request from (UsersignupForm.Request usersignupForm) {

            return Request.builder()
                    .id(usersignupForm.getId())
                    .password(usersignupForm.getPassword())
                    .name(usersignupForm.getName())
                    .phone(usersignupForm.getPhone())
                    .email(usersignupForm.getEmail())
                    .image(usersignupForm.getImage().toString())
                    .build();
        }

        // AdminsignupForm.Request -> SignupDto.Request로 변환 *24.01.19 jihyun
        public static SignupDto.Request from (AdminsignupForm.Request adminsignupForm) {

            return Request.builder()
                    .id(adminsignupForm.getId())
                    .password(adminsignupForm.getPassword())
                    .name(adminsignupForm.getName())
                    .phone(adminsignupForm.getPhone())
                    .email(adminsignupForm.getEmail())
                    .image(adminsignupForm.getImage().toString())
                    .build();
        }
    }

    @Getter
    @Builder
    public static class Response {

        private Long idx;

        private String id;

        private String password;

        private String name;

        private String phone;

        private String email;

        private String image;

        public static SignupDto.Response from(User user) {

            return Response.builder()
                    .idx(user.getIdx())
                    .id(user.getId())
                    .password(user.getPassword())
                    .name(user.getName())
                    .phone(user.getPhone())
                    .email(user.getEmail())
                    .image(user.getImage())
                    .build();
        }
    }
}
