package com.project.lotus.common.service;

import com.project.lotus.auth.entity.User;
import com.project.lotus.message.dto.MessageDto;
import com.project.lotus.product.entity.Product;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

@Service
public class SaveFileService {

    @Value("${file.dir}")
    private String fileDir;

    public String saveFile(MessageDto.Request messageDto, User buyer, Product seller) {

        // 판매자, 구매자, 상품번호 합하여 고유 텍스트 파일명 저장 *24.01.26 jihyun
        String filePath = fileDir + "/" + buyer.getIdx() + "_" + seller.getProductIdx() + ".txt";

        try {
            FileWriter fileWriter = new FileWriter(filePath, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

//            String formattedMessage = String.format("[%s] %s: %s",
//                    LocalDateTime.now(), chatMessage.getSender(), chatMessage.getContent());

            bufferedWriter.write(messageDto.getContent());
            bufferedWriter.newLine();

            bufferedWriter.close();
            fileWriter.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return filePath;
    }
}
