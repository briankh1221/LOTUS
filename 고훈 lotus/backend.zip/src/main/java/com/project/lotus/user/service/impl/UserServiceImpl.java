package com.project.lotus.user.service.impl;

import com.project.lotus.auth.dto.SignupDto;
import com.project.lotus.auth.dto.UsersignupForm;
import com.project.lotus.auth.entity.User;
import com.project.lotus.auth.repository.UserRepository;
import com.project.lotus.common.config.security.TokenProvider;
import com.project.lotus.common.exception.CustomException;
import com.project.lotus.common.service.UploadService;
import com.project.lotus.favorite.dto.FavoriteDto;
import com.project.lotus.favorite.entity.Favorite;
import com.project.lotus.favorite.repository.FavoriteRepository;
import com.project.lotus.product.dto.ProductDto;
import com.project.lotus.product.dto.ProductForm;
import com.project.lotus.product.entity.Product;
import com.project.lotus.product.repository.ProductRepository;
import com.project.lotus.review.dto.ReviewDto;
import com.project.lotus.review.dto.ReviewForm;
import com.project.lotus.review.entity.Review;
import com.project.lotus.review.repository.ReviewRepository;
import com.project.lotus.user.dto.QnaDto;
import com.project.lotus.user.dto.QnaForm;
import com.project.lotus.user.entity.Qna;
import com.project.lotus.user.repository.QnaRepository;
import com.project.lotus.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.project.lotus.common.enums.Role.ROLE_USER;
import static com.project.lotus.common.exception.ErrorCode.*;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final TokenProvider tokenProvider;
    private final PasswordEncoder passwordEncoder;

    private final UploadService uploadService;

    // Repository *24.02.01 jihyun
    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final FavoriteRepository favoriteRepository;
    private final ReviewRepository reviewRepository;
    private final QnaRepository qnaRepository;

    // 이용자 (마이 페이지) 정보 조회 *24.02.03 jihyun
    @Override
    public SignupDto.Response findProfile(String accessToken) {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        return SignupDto.Response.from(user);
    }

    // 이용자 (마이 페이지) 정보 수정 *24.02.03 jihyun
    @Override
    public void modifyProfile(String accessToken, UsersignupForm.Request usersignupForm,
                              MultipartFile image) throws IOException {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        SignupDto.Request signupDto = SignupDto.Request.from(usersignupForm);

        if (image != null && !image.isEmpty()) {
            String imagePath = uploadService.fileUpload(image);
            signupDto.setImage(imagePath);
        }

        user.modifyUser(signupDto, passwordEncoder.encode(signupDto.getPassword()));

        userRepository.save(user);
    }

    // 이용자 상품 등록 *24.01.19 jihyun
    @Override
    public void addProduct(String accessToken, ProductForm.Request productForm,
                           List<MultipartFile> images) throws IOException {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        ProductDto.Request productDto = ProductDto.Request.from(productForm);

        if (images != null && !images.isEmpty()) {
            String imagePaths = uploadService.fileUpload(images);
            productDto.setImages(imagePaths);
        }

        productRepository.save(Product.from(productDto, user));
    }

    // 이용자 상품 수정 *24.01.19 jihyun
    @Override
    public void modifyProduct(Long productIdx, ProductForm.Request productForm,
                              List<MultipartFile> images) throws IOException {

        Product product = productRepository.findById(productIdx)
                .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

        ProductDto.Request productDto = ProductDto.Request.from(productForm);

        if (images != null && !images.isEmpty()) {
            String imagePaths = uploadService.fileUpload(images);
            productDto.setImages(imagePaths);
        }

        product.modifyProduct(productDto);

        productRepository.save(product);

    }

    // 이용자 상품 삭제 *24.01.19 jihyun
    @Override
    public void removeProduct(Long productIdx) {

        Product product = productRepository.findById(productIdx)
               .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

       productRepository.delete(product);
    }

    // 이용자 찜 등록 *24.01.31 jihyun
    @Override
    public void addfavorite(String accessToken, Long productIdx) {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        Product product = productRepository.findById(productIdx)
                .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

        favoriteRepository.save(Favorite.from(user, product));
    }

    // 이용자 찜 삭제 *24.01.31 jihyun
    @Override
    public void removeFavorite(Long productIdx) {

        Product product = productRepository.findById(productIdx)
                .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

        Favorite favorite = favoriteRepository.findByProduct(product)
                .orElseThrow(() -> new CustomException(FAVORITE_NOT_EXISTS));

        favoriteRepository.delete(favorite);
    }

    // 이용자 찜 상품 조회 *24.01.19 jihyun
    @Override
    public List<FavoriteDto.Response> findFavoriteList(String accessToken) {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        List<Favorite> favoriteList = favoriteRepository.findAllByUser(user);

        List<FavoriteDto.Response> favoriteDtoList = new ArrayList<>();

        for (Favorite favorite : favoriteList) {
            favoriteDtoList.add(FavoriteDto.Response.from(favorite));
        }

        return favoriteDtoList;
    }

    // 이용자 판매 상품 조회 *24.01.24 jihyun
    @Override
    public List<ProductDto.Response> findSellingList(String accessToken) {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        List<Product> productList = productRepository.findAllByUser(user);

        List<ProductDto.Response> productDtoList = new ArrayList<>();

        for (Product product : productList) {
            productDtoList.add(ProductDto.Response.from(product));
        }

        return productDtoList;
    }

    // 이용자 리뷰 등록 *24.01.26 jihyun
    @Override
    public void addReview(String accessToken, Long productIdx, ReviewForm.Request reviewForm,
                          List<MultipartFile> images) throws IOException {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        Product product = productRepository.findById(productIdx)
                .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

        ReviewDto.Request reviewDto = ReviewDto.Request.from(reviewForm);

        if (images != null && !images.isEmpty()) {
            String imagePaths = uploadService.fileUpload(images);
            reviewDto.setImages(imagePaths);
        }

        reviewRepository.save(Review.from(reviewDto, user, product));
    }

    // 이용자 리뷰 수정 *24.01.26 jihyun
    @Override
    public void modifyReview(Long reviewIdx, ReviewForm.Request reviewForm,
                             List<MultipartFile> images) throws IOException {

        Review review = reviewRepository.findById(reviewIdx)
                .orElseThrow(() -> new CustomException(REVIEW_NOT_EXISTS));

        ReviewDto.Request reviewDto = ReviewDto.Request.from(reviewForm);

        if (images != null && !images.isEmpty()) {
            String imagePaths = uploadService.fileUpload(images);
            reviewDto.setImages(imagePaths);
        }

        review.modifyReview(reviewDto);

        reviewRepository.save(review);

    }

    // 이용자 리뷰 삭제 *24.01.26 jihyun
    @Override
    public void removeReivew(Long reviewIdx) {

        Review review = reviewRepository.findById(reviewIdx)
                .orElseThrow(() -> new CustomException(REVIEW_NOT_EXISTS));

        reviewRepository.delete(review);
    }

    // 이용자 한 상품에 대한 모든 리뷰 조회 *24.01.24 jihyun
    @Override
    public List<ReviewDto.Response> findReviewList(Long productIdx) {

        Product product = productRepository.findById(productIdx)
                .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

        List<Review> reviewList = reviewRepository.findAllByProduct(product);

        List<ReviewDto.Response> reviewDtoList = new ArrayList<>();

        for (Review review : reviewList) {
            reviewDtoList.add(ReviewDto.Response.from(review));
        }

        return reviewDtoList;
    }

    // 이용자 Q&A 게시판 등록 *24.01.28 jihyun
    @Override
    public void addQna(String accessToken, QnaForm.Request qnaForm, List<MultipartFile> images) throws IOException {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        QnaDto.Request qnaDto = QnaDto.Request.from(qnaForm);

        if (images != null && !images.isEmpty()) {
            String imagePaths = uploadService.fileUpload(images);
            qnaDto.setImages(imagePaths);
        }

        qnaRepository.save(Qna.from(qnaDto, user));
    }

    // 이용자 Q&A 게시판 수정 *24.01.28 jihyun
    @Override
    public void modifyQna(Long qnaIdx, QnaForm.Request qnaForm, List<MultipartFile> images) throws IOException {

        Qna qna = qnaRepository.findByQnaIdx(qnaIdx)
                .orElseThrow(() -> new CustomException(QNA_NOT_EXISTS));

        QnaDto.Request qnaDto = QnaDto.Request.from(qnaForm);

        if (images != null && !images.isEmpty()) {
            String imagePaths = uploadService.fileUpload(images);
            qnaDto.setImages(imagePaths);
        }

        qna.modifyQna(qnaDto);

        qnaRepository.save(qna);
    }

    // 이용자 Q&A 게시판 삭제 *24.01.28 jihyun
    @Override
    public void removeQna(Long qnaIdx) {

        Qna qna = qnaRepository.findById(qnaIdx)
                .orElseThrow(() -> new CustomException(QNA_NOT_EXISTS));

        qnaRepository.delete(qna);
    }

    // 이용자 Q&A 게시판 전체 조회 *24.01.28 jihyun
    @Override
    public List<QnaDto.Response> findQnaList() {

        List<Qna> qnaList = qnaRepository.findAll();

        List<QnaDto.Response> qnaDtoList = new ArrayList<>();

        for (Qna qna : qnaList) {
            qnaDtoList.add(QnaDto.Response.from(qna));
        }

        return qnaDtoList;
    }

    // 이용자가 작성한 Q&A 게시판 전체 조회 *24.01.28 jihyun
    @Override
    public List<QnaDto.Response> findQnaList(String accessToken) {

        String email = tokenProvider.getEmail(accessToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        List<Qna> qnaList = qnaRepository.findAllByUser(user);

        List<QnaDto.Response> qnaDtoList = new ArrayList<>();

        for (Qna qna : qnaList) {
            qnaDtoList.add(QnaDto.Response.from(qna));
        }

        return qnaDtoList;
    }
}
