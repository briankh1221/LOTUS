package com.project.lotus.message.dto;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

public class MessageDto {

    @Builder
    @Setter
    @Getter
    public static class Request {

        // 상품 인덱스 *24.02.02 jihyun
        private Long productIdx;

        // 채팅 메시지 내용 *24.02.02 jihyun
        private String content;

    }

    @Builder
    @Setter
    @Getter
    public static class Response {

        // 메시지 인덱스 *24.02.02 jihyun
        private Long MessageIdx;

        private Long productIdx;

        private String content;
    }
}
