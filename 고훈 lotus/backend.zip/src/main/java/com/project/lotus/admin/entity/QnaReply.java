package com.project.lotus.admin.entity;

import com.project.lotus.admin.dto.QnaReplyDto;
import com.project.lotus.auth.entity.User;
import com.project.lotus.common.BaseTimeEntity;
import com.project.lotus.user.entity.Qna;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;



@Entity
@Getter @Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QnaReply extends BaseTimeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long qnaReplyIdx;

    @NotNull
    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    @NotNull
    @OneToOne
    @JoinColumn(name = "qna_idx")
    private Qna qna;

    @NotBlank
    private String reply;

    @CreatedDate
    private LocalDateTime postingDate;

    // QnaReplyDto.Request -> QnaReply로 변환 *24.02.01 jihyun
    public static QnaReply from(QnaReplyDto.Request qnaReplyDto, User user, Qna qna) {

        return QnaReply.builder()
                .reply(qnaReplyDto.getReply())
                .user(user)
                .qna(qna)
                .build();
    }

    public void modifyQnaReply(QnaReplyDto.Request qnaReplyDto) {

        if (qnaReplyDto.getReply() != null) {
            this.reply = qnaReplyDto.getReply();
        }
    }
}
