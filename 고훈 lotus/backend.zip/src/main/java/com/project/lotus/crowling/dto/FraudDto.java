package com.project.lotus.crowling.dto;

public class FraudDto {
}
