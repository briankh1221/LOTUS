package com.project.lotus.message.controller;

import com.project.lotus.message.dto.ChatDto;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class ChatController {

    @MessageMapping("/chat")
    @SendTo("/topic")
    public ChatDto test() {

        System.out.println("ChatController - test 매서드");

        return null;
    }
}
