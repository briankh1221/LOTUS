package com.project.lotus.admin.controller;

import com.project.lotus.admin.dto.QnaReplyForm;
import com.project.lotus.admin.service.impl.AdminServiceImpl;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class QnaReplyController {

    private final AdminServiceImpl adminServiceImpl;

    // 관리자 답변 등록 *24.02.01 jihyun
    @PostMapping(value = "/qna/{qnaIdx}")
    public ResponseEntity<Void> replyAdd(
            @RequestHeader(name = "Authorization") String accessToken,
            @PathVariable Long qnaIdx,
            @Valid QnaReplyForm.Request qnaReplyForm) {

        adminServiceImpl.addReply(accessToken, qnaIdx, qnaReplyForm);

        return ResponseEntity.status(CREATED).build();
    }

    // 관리자 답변 수정 *24.02.01 jihyun
    @PutMapping(value = "/qna/{qnaIdx}/qnareply/{qnaReplyIdx}")
    public ResponseEntity<Void> replyModify(
            @PathVariable Long qnaReplyIdx,
            @Valid QnaReplyForm.Request qnaReplyForm) {

        adminServiceImpl.modifyReply(qnaReplyIdx, qnaReplyForm);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 관리자 답변 삭제 *24.02.01 jihyun
    @DeleteMapping(value="/qna/{qnaIdx}/qnareply/{qnaReplyIdx}")
    public ResponseEntity<Void> replyRemove(
            @PathVariable Long qnaReplyIdx) {

        adminServiceImpl.removeReply(qnaReplyIdx);

        return ResponseEntity.status(NO_CONTENT).build();
    }
}
