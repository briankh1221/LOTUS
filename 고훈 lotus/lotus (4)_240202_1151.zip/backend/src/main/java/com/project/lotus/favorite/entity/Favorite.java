package com.project.lotus.favorite.entity;


import com.fasterxml.jackson.databind.ser.Serializers;
import com.project.lotus.auth.entity.User;
import com.project.lotus.common.BaseTimeEntity;
import com.project.lotus.product.entity.Product;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;

@Builder
@Getter
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name = "favorite")
public class Favorite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="favorite_idx")
    private Long favoriteIdx;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "user_idx")
    private User user;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "product_idx")
    private Product product;

    // User(Entity), Product(Entity) -> Favorite(Entity)로 변환 *24.01.31 jihyun
    public static Favorite from(User user, Product product) {

        return Favorite.builder()
                .user(user)
                .product(product)
                .build();
    }
}
