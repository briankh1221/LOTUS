package com.project.lotus.product.dto;

import com.project.lotus.common.enums.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;


public class ProductForm {

    @Getter
    @Builder
    public static class Request {

        // 상품 카테고리 *24.01.19 jihyun
        //  @NotNull(message = "상품카테고리는 필수로 선택해야 합니다.")
        private CategoryName categoryName;

        // 상품명 *24.01.19 jihyun
        @NotBlank(message = "상품명은 필수로 입력해야 합니다.")
        private String productName;

        // 글 제목 *24.01.24 jihyun
        @NotBlank(message = "글 제목은 필수로 입력해야 합니다.")
        private String title;

        // 상품 설명 *24.01.19 jihyun
        @NotBlank(message = "상품 설명은 필수로 입력해야 합니다.")
        private String description;

        // 택배비 포함 여부 *24.01.19 jihyun
        @NotNull(message = "택비비 포함 여부 필수로 선택해야 합니다.")
        private DeliveryFee deliveryFee;

        // 상품 가격 *24.01.19 jihyun
        @NotBlank(message = "가격은 필수로 입력해야 합니다.")
        private String price;

        // 상품 이미지 *24.01.19 jihyun
        @NotNull(message = "이미지는 필수로 첨부해야 합니다.")
        private List<MultipartFile> images;

        // 상품 상태 *24.01.19 jihyun
        // @NotNull(message = "상품 상태는 필수로 선택해야 합니다.")
        private ProductStatus productStatus;

        // 거래 방법 *24.01.19 jihyun
        // @NotNull(message = "거래 방법은 필수로 선택해야 합니다.")
        private DeliveryMethod deliveryMethod;

        // 거래 가능한 주소 *24.01.19 jihyun
        @NotBlank(message = "거래 가능한 주소는 필수로 입력해야 합니다.")
        private String address;

        // 거래 상태 *24.01.19 jihyun
        // @NotNull(message = "거래 상태는 필수로 선택해야 합니다.")
        private TransactionStatus transactionStatus;
    }

    @Getter
    @Builder
    public static class Response {

        // 상품 인덱스 *24.02.01 jihyun
        private Long productIdx;

        private String id;

        private CategoryName categoryName;

        private String productName;

        private String title;

        private String description;

        private DeliveryFee deliveryFee;

        private String price;

        private List<MultipartFile> images;

        private ProductStatus productStatus;

        private DeliveryMethod deliveryMethod;

        private String address;

        private TransactionStatus transactionStatus;

        // 상품 등록 생성일 *24.02.01 jihyun
        private LocalDateTime postingDate;
    }
}
