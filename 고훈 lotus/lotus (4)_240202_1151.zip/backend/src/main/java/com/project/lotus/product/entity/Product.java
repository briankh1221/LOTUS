package com.project.lotus.product.entity;

import com.project.lotus.auth.entity.User;
import com.project.lotus.common.BaseTimeEntity;
import com.project.lotus.common.enums.*;
import com.project.lotus.product.dto.ProductDto;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Product extends BaseTimeEntity  {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productIdx;

    @NotNull
    @ManyToOne
    @JoinColumn(name ="user_idx")
    private User user;

    @Enumerated(EnumType.STRING)
    private CategoryName categoryName;

    @NotNull
    private String productName;

    @NotBlank
    private String title;

    @NotNull
    private String description;

    // @NotNull
    @Enumerated(EnumType.STRING)
    private DeliveryFee deliveryFee;

    @NotNull
    private String price;

    @NotNull
    private String images;

    // @NotNull
    @Enumerated(EnumType.STRING)
    private ProductStatus productStatus;

    // @NotNull
    @Enumerated(EnumType.STRING)
    private DeliveryMethod deliveryMethod;

    @NotNull
    private String address;

    // @NotNull
    @Enumerated(EnumType.STRING)
    private TransactionStatus transactionStatus;

    @CreatedDate
    private LocalDateTime postingDate;

    // ProductDto.Request -> Product(Entity)로 변환 *24.01.26 jihyun
    public static Product from(ProductDto.Request productDto, User user) {

        return Product.builder()
                .user(user)
                .categoryName(productDto.getCategoryName())
                .productName(productDto.getProductName())
                .title(productDto.getTitle())
                .description(productDto.getDescription())
                .deliveryFee(productDto.getDeliveryFee())
                .price(productDto.getPrice())
                .images(productDto.getImages())
                .productStatus(productDto.getProductStatus())
                .deliveryMethod(productDto.getDeliveryMethod())
                .address(productDto.getAddress())
                .transactionStatus(productDto.getTransactionStatus())
                .build();
    }

    public void modifyProduct(ProductDto.Request productDto) {

        if (productDto.getCategoryName() != null) {
            this.categoryName = productDto.getCategoryName();
        }
        if  (productDto.getProductName() != null) {
            this.productName = productDto.getProductName();
        }
        if (productDto.getTitle() != null) {
            this.title = productDto.getTitle();
        }
        if (productDto.getDescription() != null) {
            this.description = productDto.getDescription();
        }
        if (productDto.getDeliveryFee() != null) {
            this.deliveryFee = productDto.getDeliveryFee();
        }
        if (productDto.getPrice() != null) {
            this.price = productDto.getPrice();
        }
        if (productDto.getImages() != null) {
            this.images = productDto.getImages();
        }
        if (productDto.getProductStatus() != null) {
            this.productStatus = productDto.getProductStatus();
        }
        if (productDto.getDeliveryMethod() != null) {
            this.deliveryMethod = productDto.getDeliveryMethod();
        }
        if (productDto.getAddress() != null) {
            this.address = productDto.getAddress();
        }
        if (productDto.getTransactionStatus() != null) {
            this.transactionStatus = productDto.getTransactionStatus();
        }
    }
}
