package com.project.lotus.admin.repository;

import com.project.lotus.admin.entity.QnaReply;
import com.project.lotus.auth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface QnaReplyRepository extends JpaRepository<QnaReply,Long> {

    Optional<QnaReply> findByQnaReplyIdx(Long qnaReplyIdx);
}
