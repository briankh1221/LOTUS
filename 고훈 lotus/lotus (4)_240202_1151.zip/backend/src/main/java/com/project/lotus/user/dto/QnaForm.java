package com.project.lotus.user.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;


public class QnaForm {

    @Getter
    @Builder
    public static class Request {

        // Q&A 제목 *24.01.28 jihyun
        @NotBlank(message = "제목은 필수로 입력해야 합니다.")
        private String title;

        // Q&A 내용 *24.01.28 jihyun
        @NotBlank(message = "내용은 필수로 입력해야 합니다.")
        private String content;

        // Q&A 이미지 *24.01.28 jihyun
        // @NotNull(message = "이미지는 필수로 첨부해야 합니다.")
        private List<MultipartFile> images;
    }

    @Getter
    @Builder
    public static class Response {

        // Q&A 인덱스 *24.01.28 jihyun
        private Long qnaIdx;

        private String title;

        private String content;

        private List<MultipartFile> images;

        // Q&A 생성일 *24.01.19 jihyun
        private LocalDateTime postingDate;
    }
}
