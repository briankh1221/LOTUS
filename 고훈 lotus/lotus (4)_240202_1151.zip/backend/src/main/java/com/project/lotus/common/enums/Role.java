package com.project.lotus.common.enums;

public enum Role {

    // 권한: 이용자 *24.01.19 jihyun
    ROLE_USER,

    // 권한: 관리자 *24.01.19 jihyun
    ROLE_ADMIN
}
