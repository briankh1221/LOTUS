package com.project.lotus.admin.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class QnaReplyForm {

    @Getter
    @Builder
    public static class Request {

        // 관리자 답변 *24.01.30 jihyun
        @NotBlank(message = "답변은 필수로 입력해야 합니다.")
        private String reply;
    }

    @Getter
    @Builder
    public static class Response {

        // Q&A 답변 인덱스 *24.01.28 jihyun
        private Long qnaReplyIdx;

        private String reply;

        // Q&A 답변 생성일 *24.01.30 jihyun
        private String postingDate;
    }
}
