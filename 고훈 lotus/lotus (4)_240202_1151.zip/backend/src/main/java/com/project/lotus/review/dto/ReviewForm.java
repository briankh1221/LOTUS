package com.project.lotus.review.dto;

import com.project.lotus.common.enums.Evaluation;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;


public class ReviewForm {

    @Getter
    @Builder
    public static class Request {

        // 리뷰 제목 *24.01.26 jihyun
        @NotBlank(message = "제목은 필수로 입력해야 합니다.")
        private String title;

        // 리뷰 내용 *24.01.26 jihyun
        @NotBlank(message = "내용은 필수로 입력해야 합니다.")
        private String content;

        // 리뷰 이미지 *24.01.26 jihyun
        @NotNull(message = "이미지는 필수로 첨부해야 합니다.")
        private List<MultipartFile> images;

        // 리뷰 평가 *24.01.26 jihyun
        @NotNull(message = "평가는 필수로 선택해야 합니다.")
        private Evaluation evaluation;
    }

    @Getter
    @Builder
    public static class Response {

        // 리뷰 인덱스 *24.02.01 jihyun
        private Long reviewIdx;

        private String title;

        private String content;

        private List<MultipartFile> images;

        private Evaluation evaluation;

        // 생성일 *24.02.01 jihyun
        private LocalDateTime postingDate;
    }
}
