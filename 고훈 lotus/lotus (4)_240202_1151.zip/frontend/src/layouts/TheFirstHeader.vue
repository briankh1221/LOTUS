<template>
  <nav class="navbar navbar-expand-lg bg-white">
    <div class="container-fluid">
      <RouterLink class="nav-link active" to="/">
        <h3>Lotus</h3>
      </RouterLink>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="d-flex" id="navbarSupportedContent">
        <form class="d-flex" role="search">
          <input
            class="form-control"
            type="search"
            placeholder="검색"
            aria-label="Search"
            style="width: 500px"
          />
        </form>
      </div>
      <ul class="navbar-nav justify-content-end">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">채팅하기</a>
        </li>
        <li class="nav-item">
          <RouterLink class="nav-link active" to="/product/create"
            >상품 등록</RouterLink
          >
        </li>
        <li class="nav-item">
          <RouterLink class="nav-link active" to="/admin/main"
            >관리자페이지</RouterLink
          >
        </li>
        <li class="nav-item">
          <RouterLink class="nav-link active" to="/signin"
            >로그인/회원가입</RouterLink
          >
        </li>
        <li class="nav-item">
          <RouterLink class="nav-link active" to="/" @click.native="logout"
            >로그아웃</RouterLink
          >
        </li>
        <li class="nav-item">
          <RouterLink class="nav-link active" to="/my">My</RouterLink>
        </li>
        <li class="nav-item">
          <RouterLink class="nav-link active" to="/user/qna">QnA</RouterLink>
        </li>
      </ul>
    </div>
  </nav>
</template>

<script setup>
import { watchEffect } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const logout = () => {
  localStorage.removeItem('accessToken');
  localStorage.removeItem('refreshToken');
  router.push({ name: 'Home' });
};

// 토큰 상태를 관찰하여 다시 랜더링
watchEffect(() => {});
</script>

<style lang="scss" scoped></style>
