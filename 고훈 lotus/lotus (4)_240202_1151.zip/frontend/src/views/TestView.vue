<template>
  <div>
    <form>
      <div class="container text-center">
        <h2 class="justify-items-center mb-5">상품 등록 test</h2>
        <div class="row">
          <div class="col-2"></div>
          <div class="col-8 d-flex flex-column">
            <form>
              <div>
                <label for="hiddenInput" style="cursor: pointer">
                  <img
                    src="../../public/images/imageBtn.jpg"
                    width="100"
                    height="100"
                  />
                </label>
                <input
                  type="file"
                  multiple
                  id="hiddenInput"
                  name="images"
                  style="display: none"
                  @change="handleFileChange"
                />

                <div
                  class="input-group mb-3"
                  v-for="file in selectedFiles"
                  :key="file.name"
                >
                  <input
                    type="text"
                    class="form-control"
                    :value="file.name"
                    aria-label="Recipient's username"
                    aria-describedby="button-addon2"
                    readonly
                  />
                  <button
                    class="btn btn-outline-secondary"
                    type="button"
                    id="button-addon2"
                    @click.prevent="removeFile(file)"
                  >
                    삭제하기
                  </button>
                </div>
              </div>

              <button
                class="btn btn-secondary my-5"
                @click.prevent="productCreate"
              >
                작성 완료
              </button>
            </form>
          </div>
          <div class="col-2"></div>
        </div>
      </div>
      <div class="d-flex gap-2 mt-4">
        <slot name="actions"> </slot>
      </div>
    </form>
  </div>
</template>

<script setup>
import { formInstance } from '@/common/axios/axiosInstance';
import { ref } from 'vue';

const selectedFiles = ref([]);

const form = ref({
  images: [],
  title: 'title',
});

const handleFileChange = event => {
  const files = Array.from(event.target.files);

  // 이미지 파일을 File 객체로 변환하여 배열에 추가
  const fileObjects = files.map(file => new File([file], file.name));

  form.value.images = [...selectedFiles.value, ...fileObjects];
  selectedFiles.value = [...form.value.images];

  if (form.value.images.length > 10) {
    alert('사진은 10개까지만 추가 가능합니다');
    for (let i = 0; i < form.value.images.length - 10; i++) {
      form.value.images.pop();
      selectedFiles.value = [...form.value.images];
    }
  }
};

const removeFile = fileToRemove => {
  selectedFiles.value = selectedFiles.value.filter(
    file => file !== fileToRemove,
  );
};

const productCreate = async () => {
  try {
    const formData = new FormData();

    form.value.images.forEach(file => {
      console.log(file);
      console.log(file instanceof File);
      formData.append('images', file);
    });

    formData.append('title', form.value.title);
    console.log(formData.get('title'));

    await formInstance.post('/user/test', formData);
    alert('상품 등록 완료');
    // router.push({ name: 'Home' });
  } catch (error) {
    console.error(error);
    alert('상품 등록 실패!!');
  }
};
</script>

<style lang="scss" scoped></style>
