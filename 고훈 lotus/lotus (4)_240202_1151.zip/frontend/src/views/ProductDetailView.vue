<template>
  <div v-if="post">
    <br /><br />

    <div class="row">
      <!-- 사진 슬라이드 부분 -->
      <div class="col-6">
        <div id="carouselExample" class="carousel slide">
          <div class="carousel-inner">
            <div
              v-for="(image, idx) in post.images.split(' ')"
              :key="idx"
              class="carousel-item"
              :class="{ active: idx === 0 }"
            >
              <img
                :src="'/images/' + image"
                class="d-block w-100 rounded-3"
                style="height: 400px"
              />
            </div>
          </div>
          <div v-if="post.images.split(' ').length > 1">
            <button
              class="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExample"
              data-bs-slide="prev"
            >
              <span
                class="carousel-control-prev-icon"
                aria-hidden="true"
              ></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button
              class="carousel-control-next"
              type="button"
              data-bs-target="#carouselExample"
              data-bs-slide="next"
            >
              <span
                class="carousel-control-next-icon"
                aria-hidden="true"
              ></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      </div>

      <!-- 사진 오른쪽 정보 부분 -->
      <div class="col-6 mt-3">
        <p class="text-secondary">카테고리 : 의류/신발</p>
        <h4 class="mt-2">{{ post.title }}</h4>
        <h2 class="my-2">가격 : {{ price }} 원</h2>
        <div class="row mt-3">
          <div class="col-7 p-0">
            <p class="ms-3 mb-0 text-secondary">
              제품일련번호 &middot {{ post.productName }}
            </p>
          </div>
          <div class="col-5 text-end p-0">
            <RouterLink class="text-decoration-none" to="/price"
              ><p class="text-dark me-2 mb-1">
                이 상품 시세 조회하러 가기
              </p></RouterLink
            >
          </div>
        </div>

        <hr class="p-0 mt-0" />

        <div class="row mb-3">
          <div v-if="postingDate" class="col-5 ms-2">
            {{ postingDate }} &middot 조회수 20 &middot 찜 10
          </div>
          <div class="col-6 text-end ms-4">
            <RouterLink class="text-dark text-decoration-none" to="/fraud"
              ><img
                class="me-2"
                src="/images/fraudImg.jpg"
                style="width: 18px"
              />사기 조회</RouterLink
            >
          </div>
        </div>
        <div class="row">
          <div class="col-4 text-center">
            <p class="text-secondary mb-2">물품 상태</p>
            <h5 v-if="productStatus">{{ productStatus }}</h5>
          </div>
          <div class="col-4 text-center">
            <p class="text-secondary mb-2">거래 방법</p>
            <h5 v-if="deliveryMethod">{{ deliveryMethod }}</h5>
          </div>
          <div class="col-4 text-center">
            <p class="text-secondary mb-2">배송비</p>
            <h5 v-if="deliveryFee">{{ deliveryFee }}</h5>
          </div>
        </div>

        <hr class="mb-0" />

        <div class="container mt-4">
          <div class="row">
            <div class="col-md-3">
              <button
                @click="addFavorite"
                class="btn btn-outline-danger w-100"
                :class="{ active: isFavorite }"
                type="button"
              >
                찜하기
              </button>
            </div>
            <div class="col-md-9">
              <RouterLink to="/chating">
                <button class="btn btn-dark w-100" type="button">
                  채팅하기
                </button>
              </RouterLink>
            </div>
          </div>
        </div>
      </div>
    </div>

    <hr class="my-5" />

    <div class="row">
      <div class="col-6 my-0">
        <div class="p-3 bg-light text-dark text-center">
          <h5>거래 전 주의 사항</h5>
          <p class="my-0" style="font-size: 12px">
            판매자가 별도의 메신저로 결제링크를 보내거나 직거래(직접송금)을
            유도하는 경우 사기일 가능성이 높으니 거래를 자제해 주세요
          </p>
        </div>
        <p v-if="post" class="my-5" style="white-space: pre-line">
          {{ post.description }}
        </p>
      </div>
      <div class="col-6">판매자 간단 정보</div>
    </div>
  </div>
</template>

<script setup>
import { instance } from '@/common/axios/axiosInstance';
import { onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const { productIdx, price, postingDate } = history.state;
const post = ref();
const productStatus = ref('');
const deliveryMethod = ref('');
const deliveryFee = ref('');
const isFavorite = ref(false);

// 게시글의 정보 db 에서 받아오는 매서드
const fetchDetail = async () => {
  try {
    const response = await instance.get('/product/' + productIdx);
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

onMounted(async () => {
  // DB에서 정보 추출 ==========================================================================================
  post.value = await fetchDetail();
  // DB에서 정보 추출 종료 =====================================================================================

  //
  //
  // ====== enum 선택 옵션 값들 처리 ===========================================================================
  // 물품 상태
  if (post.value.productStatus == 'EXCELLENT') {
    productStatus.value = '최상';
  } else if (post.value.productStatus == 'GOOD') {
    productStatus.value = '상';
  } else if (post.value.productStatus == 'FAIR') {
    productStatus.value = '중';
  } else if (post.value.productStatus == 'POOR') {
    productStatus.value = '하';
  } else if (post.value.productStatus == 'VERY_POOR') {
    productStatus.value = '최하';
  }

  // 배송방법
  if (post.value.deliveryMethod == 'SHIPPING_SERVICE') {
    deliveryMethod.value = '택배거래';
  } else if (post.value.deliveryMethod == 'DIRECT_DEAL') {
    deliveryMethod.value = '직거래';
  }

  // 배송비 포함 여부
  if (post.value.deliveryFee == 'INCLUDING_DELIVERY_FEE') {
    deliveryFee.value = '포함';
  } else if (post.value.deliveryFee == 'NOT_INCLUDING_DELIVERY_FEE') {
    deliveryFee.value = '미포함';
  }
  // ====== enum 선택 옵션 값들 처리 종료 ===========================================================================
});

//
// ====== 찜하기 버튼 처리 ==========================================================================================
// 페이지 접속한 직후 찜 했는지 여부 확인
const fetchIsFavorite = async () => {
  try {
    const response = await instance.get('user/product/favorite');
    console.log(response.data);
    response.data.map(x => {
      if (x.productIdx == productIdx) {
        isFavorite.value = true;
        return;
      }
    });
  } catch (error) {
    console.error(error);
  }
};
fetchIsFavorite();

// 찜하기 버튼을 누른 상황 처리
// 찜 추가 하는 매서드 선언
const fetchFavoriteAdd = async () => {
  try {
    const response = await instance.post(
      '/user/product/' + productIdx + '/favorite',
    );
    console.log(response);
    isFavorite.value = true;
  } catch (error) {
    console.error(error);
  }
};

// 찜 삭제 하는 매서드 선언
const fetchFavoriteDelete = async () => {
  try {
    const response = await instance.delete(
      '/user/product/' + productIdx + '/favorite',
    );
    console.log(response);
    isFavorite.value = false;
  } catch (error) {
    console.error(error);
    console.error(error.request);
  }
};

// 찜 버튼 클릭시 작동되는 매서드
const addFavorite = () => {
  // accessToken의 존재 여부로 회원인지 아닌지 판별
  if (localStorage.getItem('accessToken')) {
    // 회원이지만 찜버튼을 누르지 않은 상태
    if (!isFavorite.value) {
      fetchFavoriteAdd();
    } else if (isFavorite.value) {
      fetchFavoriteDelete();
    }
  } else {
    alert('회원만 찜 가능');
    router.push({ name: 'Signin' });
  }
};
// ====== 찜하기 버튼 처리 종료 ==========================================================================================
</script>

<style lang="scss" scoped></style>
