<template>
  <div class="container text-center">
    <h2 class="justify-items-center mb-5">사기 조회</h2>
  </div>
  <hr />
</template>

<script setup></script>

<style lang="scss" scoped></style>
