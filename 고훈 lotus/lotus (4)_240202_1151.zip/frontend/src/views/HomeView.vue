<template>
  <br /><br />

  <!-- 광고 표시 부분 -->
  <div id="carouselExample" class="carousel slide">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img
          src="/images/tj_advertise_01.jpg"
          class="d-block mb-5"
          style="width: 100%; height: 400px"
        />
      </div>
      <div class="carousel-item">
        <img
          src="/images/tj_advertise_02.jpg"
          class="d-block w-100 mb-5"
          style="width: 100%; height: 400px"
        />
      </div>
      <div class="carousel-item">
        <img
          src="/images/tj_advertise_03.jpg"
          class="d-block w-100 mb-5"
          style="width: 100%; height: 400px"
        />
      </div>
    </div>
    <button
      class="carousel-control-prev"
      type="button"
      data-bs-target="#carouselExample"
      data-bs-slide="prev"
    >
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button
      class="carousel-control-next"
      type="button"
      data-bs-target="#carouselExample"
      data-bs-slide="next"
    >
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

  <!-- 최고 인기 상품 표시 부분 -->
  <div>
    <h2>최고 인기 상품</h2>
    <hr class="my-4" />
    <br /><br /><br /><br />
  </div>

  <!-- 최신 상품 표시 부분 -->
  <div>
    <h2>최신 상품</h2>
    <hr class="my-4" />

    <div class="row">
      <div
        v-for="post in recentPosts"
        :key="post.productIdx"
        class="col-3 mb-4"
        @click="goDetailPage(post.productIdx, post.price, post.postingDate)"
      >
        <div
          class="card"
          :class="{
            'border-1': isHover[post.productIdx],
            'border-0': !isHover[post.productIdx],
            'mt-0': isHover[post.productIdx],
            'mt-1': !isHover[post.productIdx],
          }"
          style="width: 100%"
          @mouseover="setHover(post.productIdx, true)"
          @mouseleave="setHover(post.productIdx, false)"
        >
          <img
            :src="'/images/' + post.images.split(' ')[0]"
            class="card-img-top"
            style="width: 100%; height: 250px; object-fit: cover"
          />
          <div class="card-body">
            <p class="card-title text-secondary">{{ post.title }}</p>
            <div class="row">
              <div class="col-6">
                <p class="card-text" style="font-weight: 800">
                  {{ post.price }} 원
                </p>
              </div>
              <div class="col-6 text-end">
                <p class="text-secondary mt-1" style="font-size: 12px">
                  {{ post.postingDate }}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <br /><br /><br /><br />
  </div>

  <!-- 카테고리별 상품 표시 부분 -->
  <div>
    <h2>카테고리별 상품</h2>
    <hr class="my-4" />
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import { instance } from '@/common/axios/axiosInstance';
import { useRouter } from 'vue-router';

const router = useRouter();
const recentPosts = ref([]);
const isHover = ref({});

const fetchRecent = async () => {
  try {
    const response = await instance.get('/product/recent-list');
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

const setHover = (idx, value) => {
  isHover.value[idx] = value;
};

const goDetailPage = (productIdx, price, postingDate) => {
  router.push({
    name: 'ProductDetail',
    state: { productIdx, price, postingDate },
  });
};

onMounted(async () => {
  // 최신 상품 목록 가져오기 ==============================================================================
  recentPosts.value = await fetchRecent();
  // 최신 상품 목록 가져오기 종료 =========================================================================

  //
  //
  // 경과 시간 값 처리하기 ================================================================================
  for (let i = 0; i < recentPosts.value.length; i++) {
    // 게시물 정보에서 날짜 추출
    const postingDate = ref();
    postingDate.value = recentPosts.value[i].postingDate;

    // 초기 문자열 이므로 날짜 객체로 변경
    const dateObject = new Date(
      parseInt(postingDate.value.substring(0, 4)),
      parseInt(postingDate.value.substring(5, 7)) - 1, // 월은 0부터 시작하므로 -1
      parseInt(postingDate.value.substring(8, 10)),
      parseInt(postingDate.value.substring(11, 13)),
      parseInt(postingDate.value.substring(14, 16)),
      parseInt(postingDate.value.substring(17, 19)),
    );

    // 현재 시간과 차이 구해서 초로 변환
    const now = new Date();
    postingDate.value = dateObject.getTime() - now.getTime();

    postingDate.value = -Math.floor(postingDate.value / 1000);

    // 초 단위로 된 시간 차이 => 표현 형식 변경
    if (postingDate.value < 60) {
      postingDate.value = postingDate.value + ' 초 전';
    } else if (postingDate.value < 3600) {
      postingDate.value = Math.floor(postingDate.value / 60) + ' 분 전';
    } else {
      postingDate.value =
        Math.floor(postingDate.value / (60 * 60)) + ' 시간 전';
    }
    recentPosts.value[i].postingDate = postingDate.value;
  }

  // 경과 시간 값 처리하기 종료 ============================================================================

  //
  //
  // 가격에 , 추가하기 ===================================================================================
  for (let idx = 0; idx < recentPosts.value.length; idx++) {
    // 필요한 변수 설정
    const noCommaPrice = recentPosts.value[idx].price;
    const commaPrice = ref('');
    const length = noCommaPrice.length;
    const commaIdx = length % 3;

    // 인덱스로 가격을 자르고 뒷부분에 ,를 추가해주는 매서드 선언
    const addComma = (startIdx, endIdx) => {
      commaPrice.value =
        commaPrice.value + noCommaPrice.substring(startIdx, endIdx) + ',';
    };

    // 3자리 이하는 , 추가  필요 없음
    if (noCommaPrice.length <= 3) {
      commaPrice.value = noCommaPrice;
    }

    for (let i = 0; i < Math.ceil(noCommaPrice.length / 3) - 1; i++) {
      // 자리수가 3의 배수일 때
      if (commaIdx == 0) {
        addComma(3 * i, 3 * (i + 1));
        if (i == Math.ceil(noCommaPrice.length / 3) - 2) {
          addComma(length - 3, length);
        }
        // 자리수가 3의 배수가 아닐 때
      } else {
        if (i == 0) {
          addComma(0, commaIdx);
        }
        addComma(3 * i + commaIdx, 3 * (i + 1) + commaIdx);
      }
    }
    // 마지막에 ,가 추가된 경우 해당 , 삭제
    if (
      commaPrice.value.substring(
        commaPrice.value.length - 1,
        commaPrice.value.length,
      ) == ','
    ) {
      commaPrice.value = commaPrice.value.substring(
        0,
        commaPrice.value.length - 1,
      );
    }
    recentPosts.value[idx].price = commaPrice.value;
    // 가격에 , 추가하기 종료 ===============================================================================
  }
});
</script>

<style lang="scss" scoped></style>
