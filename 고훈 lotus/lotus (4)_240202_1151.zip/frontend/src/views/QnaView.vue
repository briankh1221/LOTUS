<template>
  <div class="container text-center">
    <h2 class="justify-items-center">QnA 게시판</h2>
  </div>
  <div class="container">
    <hr class="mb-5" />
    <h4>내가 작성한 질문</h4>
    <hr class="mb-5" />
    <h4>새로운 질문 작성</h4>
    <hr class="mb-5" />
    <div class="col-4 d-flex flex-column">
      <input
        v-model="form.title"
        type="text"
        class="my-3"
        placeholder="  제목 입력"
      />
      <textarea
        v-model="form.content"
        type="text"
        placeholder="  내용 입력"
      ></textarea>
      <button class="btn btn-secondary my-5" @click.prevent="qnaMethod">
        작성 완료
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { instance } from '@/common/axios/axiosInstance';

const router = useRouter();

const form = ref({
  title: null,
  content: null,
});

const qnaMethod = async () => {
  try {
    await instance.post('/auth/signin', { ...form.value });

    alert('로그인 성공!!');
    router.push({ name: 'Home' });
  } catch (error) {
    console.error(error);
    alert('로그인 실패!!');
  }
};
</script>

<style lang="scss" scoped></style>
