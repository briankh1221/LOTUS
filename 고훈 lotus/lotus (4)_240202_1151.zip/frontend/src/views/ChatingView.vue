<template>
  <div class="container text-center">
    <h2 class="justify-items-center mb-5">채팅 하기</h2>
  </div>
  <hr />
</template>

<script setup></script>

<style lang="scss" scoped></style>
