<template>
  <div>
    <h2>관리자 메인 페이지</h2>
    <hr class="my-4" />
  </div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
