<template>
  <div class="container text-center"></div>
  <hr />
  <div class="row">
    <div class="col-2">
      <p class="justify-items-center fs-4">마이 페이지</p>
      <p class="justify-items-center fs-5 mb-1">쇼핑 정보</p>
      <hr class="w-75 mt-0" />
      <p class="justify-items-center fs-6 mb-1">판매 내역</p>
      <p class="justify-items-center fs-6 mb-1">구매 내역</p>
      <p class="justify-items-center fs-6 mb-1">찜한 상품</p>

      <p class="justify-items-center fs-5 mb-1 mt-3">개인 정보</p>
      <hr class="w-75 mt-0" />
      <p class="justify-items-center fs-6 mb-1">정보 수정</p>
      <p class="justify-items-center fs-6 mb-1">후기 관리</p>
    </div>
    <div class="col-10">
      <div
        class="row border rounded-2"
        style="width: 100%; height: 200px"
      ></div>
    </div>
  </div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
