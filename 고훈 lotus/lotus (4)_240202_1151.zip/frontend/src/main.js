import { createApp } from 'vue';

import App from './App.vue';
import router from '@/router';
import store from '@/common/store/index';

import 'bootstrap/dist/css/bootstrap.css'; // 부트스트랩 CSS 임포트
import 'bootstrap/dist/js/bootstrap.bundle.min.js'; // 부트스트랩 JS 임포트

const app = createApp(App);

app.use(store);
app.use(router);

app.mount('#app');
