import axios from 'axios';
import VueJwtDecode from 'vue-jwt-decode';

const instance = axios.create({
  baseURL: 'http://localhost:8081/',
  headers: {
    'Content-Type': 'application/json',
    // 'Content-Type': 'application/x-www-form-urlencoded',
    //'Content-Type': 'multipart/form-data',
  },
});

const formInstance = axios.create({
  baseURL: 'http://localhost:8081/',
  headers: {
    'Content-Type': 'multipart/form-data',
  },
});

// ==================================================================
// instance 에 관련된 인터셉터 설정 ===================================
// ==================================================================
instance.interceptors.request.use(
  config => {
    console.log(
      '===========request 전에 intercept ============================',
    );
    const url = config.url;

    // url이 /refreshToken인 경우는 refreshToken만 가져감
    if (url == '/refreshToken') {
      const refreshToken = localStorage.getItem('refreshToken');
      config.headers['refreshToken'] = refreshToken;
      return config;
    }

    const accessToken = localStorage.getItem('accessToken');

    // 그 이외의 모든 경우에는 accessToken이 저장된 경우 accessToken을 가져감
    if (accessToken) {
      config.headers['Authorization'] = accessToken;
      config.headers['Content-Type'] = 'multipart/form-data';
    }
    return config;
  },
  error => {
    console.log(
      '===========request 전에 intercept 에러============================',
    );
    return Promise.reject(error);
  },
);
instance.interceptors.response.use(
  response => {
    console.log(
      '===========response 전에 intercept ============================',
    );

    // 정상적으로 로그인한 경우 tokenDto에 2개의 토큰이 담겨서 response 됨
    // 2개의 토큰을 각각의 이름으로 localStorage에 저장
    if (response.data.tokenDto) {
      const { accessToken, refreshToken } = response.data.tokenDto;
      if (accessToken) {
        localStorage.setItem('accessToken', accessToken);
      }
      if (refreshToken) {
        localStorage.setItem('refreshToken', refreshToken);
      }
    }

    return response;
  },
  error => {
    console.log(
      '===========response 전에 intercept 에러 ============================',
    );
    return Promise.reject(error);
  },
);

// =====================================================================
// formInstance 에 관련된 인터셉터 설정 ==================================
// =====================================================================

formInstance.interceptors.request.use(
  config => {
    console.log(
      '=========== formInstance request 전에 intercept ============================',
    );
    const url = config.url;

    // url이 /refreshToken인 경우는 refreshToken만 가져감
    if (url == '/refreshToken') {
      const refreshToken = localStorage.getItem('refreshToken');
      config.headers['refreshToken'] = refreshToken;
      return config;
    }

    const accessToken = localStorage.getItem('accessToken');

    // 그 이외의 모든 경우에는 accessToken이 저장된 경우 accessToken을 가져감
    if (accessToken) {
      config.headers['Authorization'] = accessToken;
    }
    return config;
  },
  error => {
    console.log(
      '===========request 전에 intercept 에러============================',
    );
    return Promise.reject(error);
  },
);
formInstance.interceptors.response.use(
  response => {
    console.log(
      '===========response 전에 intercept ============================',
    );

    // 정상적으로 로그인한 경우 tokenDto에 2개의 토큰이 담겨서 response 됨
    // 2개의 토큰을 각각의 이름으로 localStorage에 저장
    if (response.data.tokenDto) {
      const { accessToken, refreshToken } = response.data.tokenDto;
      if (accessToken) {
        localStorage.setItem('accessToken', accessToken);
        console.log(VueJwtDecode.decode(accessToken).exp);
      }
      if (refreshToken) {
        localStorage.setItem('refreshToken', refreshToken);
      }
    }

    return response;
  },
  error => {
    console.log(
      '===========response 전에 intercept 에러 ============================',
    );

    return Promise.reject(error);
  },
);

export { instance, formInstance };
