import { createStore } from 'vuex';

const store = createStore({
  state: {
    // 상태(State) 정의
    role: 'none',
  },
  mutations: {
    // 변이(Mutation) 정의
    setRole(state, role) {
      state.role = role;
    },
  },
  actions: {
    // 액션(Action) 정의
    Role({ commit }, role) {
      // 비동기 작업 등을 수행 후 변이 호출
      commit('setRole', role);
    },
  },
  getters: {
    // 게터(Getter) 정의
    getRole: state => state.role,
  },
});

export default store;
