import VueJwtDecode from 'vue-jwt-decode';

const isExpired = accessToken => {
  const expiration = VueJwtDecode.decode(accessToken).exp;

  return Math.floor(Date.now() / 1000) > expiration ? true : false;
};

const getRole = accessToken => {
  const role = VueJwtDecode.decode(accessToken).role;

  return role;
};

export { isExpired, getRole };
