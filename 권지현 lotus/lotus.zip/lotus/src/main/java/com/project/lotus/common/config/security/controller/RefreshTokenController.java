package com.project.lotus.common.config.security.controller;


import com.project.lotus.common.config.security.service.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class RefreshTokenController {

    private final JwtService jwtService;

    @PostMapping("/refreshToken")
    public ResponseEntity<RefreshTokenResponse> validateRefreshToken (
            @RequestBody HashMap<String, String> bodyJson) {

        Map<String, String> map = jwtService.validateRefreshToken(bodyJson.get("refreshToken"));

        RefreshTokenResponse refreshTokenResponse = new RefreshTokenResponse(map);

        if(map.get("status").equals("402")) {
            return new ResponseEntity<RefreshTokenResponse>(refreshTokenResponse, HttpStatus.UNAUTHORIZED);
        }

        return new ResponseEntity<RefreshTokenResponse>(refreshTokenResponse, HttpStatus.OK);

    }

    public static class RefreshTokenResponse {

        // Refresh Token 상태 *24.01.24 jihyun
        private final String status;
        // Refresh Token 메시지 *24.01.24 jihyun
        private final String message;

        public RefreshTokenResponse(Map<String, String> map) {
            this.status = map.get("status");
            this.message = map.get("message");
        }

    }

}
