package com.project.lotus.review.dto;

import com.project.lotus.common.enums.Evaluation;
import com.project.lotus.review.entity.Review;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;


public class ReviewDto {

    @Builder
    @Setter
    @Getter
    public static class Request {

        // 리뷰 제목 *24.01.26 jihyun
        private String title;

        // 리뷰 내용 *24.01.26 jihyun
        private String content;

        // 리뷰 이미지 *24.01.26 jihyun
        private String images;

        // 리뷰 평가 *24.01.26 jihyun
        private Evaluation evaluation;

        // ReviewForm -> ReviewDto로 변환 *24.01.26 jihyun
        public static ReviewDto.Request from(ReviewForm.Request reviewForm) {

            return Request.builder()
                    .title(reviewForm.getTitle())
                    .content(reviewForm.getContent())
                    .images(reviewForm.getImages().toString())
                    .evaluation(reviewForm.getEvaluation())
                    .build();
        }
    }

    @Builder
    @Setter
    @Getter
    public static class Response {

        // 리뷰 인덱스 *24.02.01 jihyun
        private Long reviewIdx;

        private String title;

        private String content;

        private String images;

        private Evaluation evaluation;

        private LocalDateTime postingDate;

        // Review(Entity) -> ReviewDto로 변환 *24.01.26 jihyun
        public static ReviewDto.Response from(Review review) {

            return Response.builder()
                    .reviewIdx(review.getReviewIdx())
                    .title(review.getTitle())
                    .content(review.getContent())
                    .images(review.getImages())
                    .evaluation(review.getEvaluation())
                    .postingDate(review.getPostingDate())
                    .build();
        }
    }
}
