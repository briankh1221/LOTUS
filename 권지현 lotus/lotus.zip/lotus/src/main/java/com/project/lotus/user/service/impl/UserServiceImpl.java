package com.project.lotus.user.service.impl;

import com.project.lotus.common.exception.CustomException;
import com.project.lotus.favorite.dto.FavoriteDto;
import com.project.lotus.favorite.entity.Favorite;
import com.project.lotus.favorite.repository.FavoriteRepository;
import com.project.lotus.product.dto.ProductDto;
import com.project.lotus.product.dto.ProductForm;
import com.project.lotus.product.entity.Product;
import com.project.lotus.product.repository.ProductRepository;
import com.project.lotus.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.project.lotus.common.exception.ErrorCode.*;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final ProductRepository productRepository;

    private final FavoriteRepository favoriteRepository;

    // 이용자 상품 등록 *24.01.19 jihyun
    @Override
    public ProductDto.Response addProduct(MultipartFile image, ProductForm.Request productForm)
            throws IOException {

        ProductDto.Request productDto = ProductDto.from(productForm);

        Product product = productRepository.save(Product.from(productDto));

        return ProductDto.Response.from(product);
    }

    // 이용자 상품 수정 *24.01.19 jihyun
    @Override
    @Transactional
    public void modifyProduct(MultipartFile image, ProductForm.Response productForm)
            throws IOException {

        ProductDto.Response productDto = ProductDto.Response.from(productForm);

        Product product = productRepository.findById(productDto.getProductIdx())
                .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

        product.modifyProduct(productDto);
    }

    // 이용자 상품 삭제 *24.01.19 jihyun
    @Override
    public void removeProduct(MultipartFile image, ProductForm.Response productForm)
            throws IOException {

        ProductDto.Response productDto = ProductDto.Response.from(productForm);

        Product product = productRepository.findById(productDto.getProductIdx())
               .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

       productRepository.deleteById(productDto.getProductIdx());
    }

    // 이용자 찜 상품 조회 *24.01.19 jihyun
    @Override
    public List<FavoriteDto.Response> findFavoriteProductList(Long idx) {

        List<Favorite> favoriteList = favoriteRepository.findAllByIdx(idx);

        List<FavoriteDto.Response> favoriteDtoList = new ArrayList<>();

        for (Favorite favorite : favoriteList) {
            favoriteDtoList.add(FavoriteDto.Response.from(favorite));
        }

        return favoriteDtoList;
    }

    // 이용자 판매 상품 조회 *24.01.24 jihyun
    @Override
    public List<ProductDto.Response> findSellingList(Long idx) {

        List<Product> productList = productRepository.findAllByIdx(idx);

        List<ProductDto.Response> productDtoList = new ArrayList<>();

        for (Product product : productList) {
            productDtoList.add(ProductDto.Response.from(product));
        }

        return productDtoList;
    }
}
