package com.project.lotus.user.service.impl;

import com.project.lotus.auth.entity.User;
import com.project.lotus.auth.repository.UserRepository;
import com.project.lotus.common.config.security.TokenProvider;
import com.project.lotus.common.exception.CustomException;
import com.project.lotus.favorite.dto.FavoriteDto;
import com.project.lotus.favorite.entity.Favorite;
import com.project.lotus.favorite.repository.FavoriteRepository;
import com.project.lotus.product.dto.ProductDto;
import com.project.lotus.product.dto.ProductForm;
import com.project.lotus.product.entity.Product;
import com.project.lotus.product.repository.ProductRepository;
import com.project.lotus.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.project.lotus.common.exception.ErrorCode.*;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final ProductRepository productRepository;

    private final FavoriteRepository favoriteRepository;

    private final UserRepository userRepository;

    private final TokenProvider tokenProvider;

    // 이용자 상품 등록 *24.01.19 jihyun
    @Override
    public ProductDto.Response addProduct(MultipartFile image, ProductForm.Request productForm, String token)
            throws IOException {

        Long userIdx = tokenProvider.getIdx(token);

        User user = userRepository.findByIdx(userIdx)
                .orElseThrow(() ->  new CustomException(USER_NOT_EXISTS));

        ProductDto.Request productDto = ProductDto.Request.from(productForm);

        Product product = productRepository.save(Product.from(productDto, user));

        return ProductDto.Response.from(product);
    }

    // 이용자 상품 수정 *24.01.19 jihyun
    @Override
    @Transactional
    public void modifyProduct(MultipartFile image, ProductForm.Request productForm)
            throws IOException {

        ProductDto.Request productDto = ProductDto.Request.from(productForm);

        Product product = productRepository.findById(productDto.getProductIdx())
                .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

        product.modifyProduct(productDto);

        productRepository.save(product);
    }

    // 이용자 상품 삭제 *24.01.19 jihyun
    @Override
    public void removeProduct(Long productIdx)
            throws IOException {

        Product product = productRepository.findById(productIdx)
               .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

       productRepository.delete(product);
    }

    // 이용자 찜 상품 조회 *24.01.19 jihyun
    @Override
    public List<FavoriteDto.Response> findFavoriteProductList(String token) {

        Long userIdx = tokenProvider.getIdx(token);

        User user = userRepository.findByIdx(userIdx)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        List<Favorite> favoriteList = favoriteRepository.findAllByUserIdx(user);

        List<FavoriteDto.Response> favoriteDtoList = new ArrayList<>();

        for (Favorite favorite : favoriteList) {
            favoriteDtoList.add(FavoriteDto.Response.from(favorite));
        }

        return favoriteDtoList;
    }

    // 이용자 판매 상품 조회 *24.01.24 jihyun
    @Override
    public List<ProductDto.Response> findSellingList(String token) {

        Long userIdx = tokenProvider.getIdx(token);

        User user = userRepository.findByIdx(userIdx)
                .orElseThrow(() -> new CustomException(USER_NOT_EXISTS));

        List<Product> productList = productRepository.findAllByUser(user);

        List<ProductDto.Response> productDtoList = new ArrayList<>();

        for (Product product : productList) {
            productDtoList.add(ProductDto.Response.from(product));
        }

        return productDtoList;
    }
}
