package com.project.lotus.user.service;

import com.project.lotus.favorite.dto.FavoriteDto;
import com.project.lotus.product.dto.ProductDto;
import com.project.lotus.product.dto.ProductForm;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface UserService {

    // 이용자 상품 등록 *24.01.19 jihyun
    public void addProduct(MultipartFile image, ProductForm.Request productForm, String token)
            throws IOException;

    // 이용자 상품 수정 *24.01.19 jihyun
    public void modifyProduct(MultipartFile image, ProductForm.Request productForm, Long productIdx)
            throws IOException;

    // 이용자 상품 삭제 *24.01.19 jihyun
    public void removeProduct(Long productIdx)
            throws IOException;

    // 이용자 찜 상품 조회 *24.01.19 jihyun
    public List<FavoriteDto.Response> findFavoriteList(String token);

    // 이용자 판매 상품 조회 *24.01.24 jihyun
    public List<ProductDto.Response> findSellingList(String token);
}
