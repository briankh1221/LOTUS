package com.project.lotus.user.service;

import com.project.lotus.auth.dto.SignupDto;
import com.project.lotus.auth.dto.UsersignupForm;
import com.project.lotus.favorite.dto.FavoriteDto;
import com.project.lotus.product.dto.ProductDto;
import com.project.lotus.product.dto.ProductForm;
import com.project.lotus.review.dto.ReviewDto;
import com.project.lotus.review.dto.ReviewForm;
import com.project.lotus.user.dto.QnaDto;
import com.project.lotus.user.dto.QnaForm;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface UserService {

    // 이용자 (마이 페이지) 정보 조회 *24.02.03 jihyun
    public SignupDto.Response findProfile (String accessToken);

    // 이용자 (마이 페이지) 정보 수정 *24.02.03 jihyun
    public void modifyProfile (String AccessToken, UsersignupForm.Request usersignupForm, MultipartFile image) throws IOException;

    // 이용자 상품 등록 *24.01.19 jihyun
    public void addProduct(String accessToken, ProductForm.Request productForm, List<MultipartFile> images)
            throws IOException;

    // 이용자 상품 수정 *24.01.19 jihyun
    public void modifyProduct(Long productIdx, ProductForm.Request productForm, List<MultipartFile> images)
            throws IOException;

    // 이용자 상품 삭제 *24.01.19 jihyun
    public void removeProduct(Long productIdx)
            throws IOException;

    // 이용자 찜 등록 *24.01.31 jihyun
    public void addfavorite(String accessToken, Long productIdx);

    // 이용자 찜 삭제 *24.01.31 jihyun
    public void removeFavorite(Long productIdx);

    // 이용자 찜 상품 조회 *24.01.19 jihyun
    public List<FavoriteDto.Response> findFavoriteList(String accessToken);

    // 이용자 판매 상품 조회 *24.01.24 jihyun
    public List<ProductDto.Response> findSellingList(String accessToken);

    // 이용자 리뷰 등록 *24.01.26 jihyun
    public void addReview(String accessToken, Long productIdx, ReviewForm.Request reviewForm, List<MultipartFile> images) throws IOException;

    // 이용자 리뷰 수정 *24.01.26 jihyun
    public void modifyReview(Long reviewIdx, ReviewForm.Request reviewForm, List<MultipartFile> images) throws IOException;

    // 이용자 리뷰 삭제 *24.01.26 jihyun
    public void removeReivew(Long reviewIdx);

    // 이용자 한 상품에 대한 모든 리뷰 조회 *@4.01.24 jihyun
    public List<ReviewDto.Response> findReviewList(Long productIdx);

    // 이용자 Q&A 게시판 등록 *24.01.28 jihyun
    public void addQna(String accessToken, QnaForm.Request qnaForm, List<MultipartFile> images) throws IOException;

    // 이용자 Q&A 게시판 수정 *24.01.28 jihyun
    public void modifyQna(Long qnaIdx, QnaForm.Request qnaForm, List<MultipartFile> images) throws IOException;

    // 이용자 Q&A 게시판 삭제 *24.01.28 jihyun
    public void removeQna(Long qnaIdx);

    // 이용자 Q&A 게시판 전체 조회 *24.01.28 jihyun
    public List<QnaDto.Response> findQnaList();

    // 이용자가 작성한 Q&A 게시판 전체 조회 *24.01.28 jihyun
    public List<QnaDto.Response> findQnaList(String accessToken);
}
