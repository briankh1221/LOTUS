package com.project.lotus.user.dto;

import com.project.lotus.user.entity.Qna;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;


public class QnaDto {

    @Builder
    @Getter
    @Setter
    public static class Request {

        // Q&A 제목 *24.01.28 jihyun
        private String title;

        // Q&A 내용 *24.01.28 jihyun
        private String content;

        // Q&A 이미지 *24.01.28 jihyun
        private String images;

        // QnaForm -> QnaDto로 변환 *24.01.28 jihyun
        public static QnaDto.Request from(QnaForm.Request qnaForm) {

            return Request.builder()
                    .title(qnaForm.getTitle())
                    .content(qnaForm.getContent())
                    .images(qnaForm.getImages().toString())
                    .build();
        }
    }

    @Builder
    @Getter
    @Setter
    public static class Response {

        // Q&A 인덱스 *24.02.01 jihyun
        private Long qnaIdx;

        private String title;

        private String content;

        private String images;

        // 생성일 *24.02.01 jihyun
        private LocalDateTime postingDate;

        // Qna(Entity) -> QnaDto로 변환 *24.01.28 jihyun
        public static QnaDto.Response from(Qna qna) {

            return Response.builder()
                    .qnaIdx(qna.getQnaIdx())
                    .title(qna.getTitle())
                    .content(qna.getContent())
                    .images(qna.getImages())
                    .postingDate(qna.getPostingDate())
                    .build();
        }
    }



}
