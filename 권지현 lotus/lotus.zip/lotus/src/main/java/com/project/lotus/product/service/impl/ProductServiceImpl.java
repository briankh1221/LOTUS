package com.project.lotus.product.service.impl;

import com.project.lotus.common.enums.CategoryName;
import com.project.lotus.common.exception.CustomException;
import com.project.lotus.favorite.repository.FavoriteRepository;
import com.project.lotus.product.dto.ProductDto;
import com.project.lotus.product.entity.Product;
import com.project.lotus.product.repository.ProductRepository;
import com.project.lotus.product.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.project.lotus.common.exception.ErrorCode.PRODUCT_NOT_EXISTS;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    // Repository *24.02.01 jihyun
    private final ProductRepository productRepository;
    private final FavoriteRepository favoriteRepository;

    // 상품 상세 정보 조회 *24.01.24 jihyun
    @Override
    public ProductDto.Response findProductDetails(Long productIdx) {

        Product product = productRepository.findById(productIdx)
                .orElseThrow(() -> new CustomException(PRODUCT_NOT_EXISTS));

        return ProductDto.Response.from(product);
    }

    // 카테고리별 상품 목록 조회 *24.01.24 jihyun
    @Override
    public List<ProductDto.Response> findProductList(CategoryName categoryName) {

        List<Product> productList = productRepository.findAllByCategoryName(categoryName);

        List<ProductDto.Response> productDtoList = new ArrayList<>();

        for (Product product : productList) {
            productDtoList.add(ProductDto.Response.from(product));
        }

        return productDtoList;
    }

    // 최신 상품 조회 *24.01.24 jihyun
    @Override
    public List<ProductDto.Response> findRecentProductList() {

        List<Product> productList = productRepository.findFirst10ByOrderByPostingDateDesc();

        List<ProductDto.Response> productDtoList = new ArrayList<>();

        for (Product product : productList) {
            productDtoList.add(ProductDto.Response.from(product));
        }

        return productDtoList;
    }

    // 베스트 찜 상품 조회 *24.01.24 jihyun
    @Override
    public List<Long> findBestProductList() {

        List<Object[]> productList = favoriteRepository.findProductCountOrderByProductIdxDesc();

        List<Long> productIdxList = new ArrayList<>();

        for (Object[] product : productList) {
            productIdxList.add((Long) product[0]);
        }

        return productIdxList;
    }
}
