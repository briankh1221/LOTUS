package com.project.lotus.common.config.security.dto;


import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TokenDto {
//    OAuth 2.0 인증 프로토콜에서 사용하는 매개변수임. 아직 확정되지 않음 *24.01.22 jihyun
//    private String grantType;

    // Access Token *24.01.22 jihyun
    private String accessToken;

    // Refresh Token *24.01.22 jihyun
    private String refreshToken;

    // Email *24.01.22 jihyun
    private String key;
}
