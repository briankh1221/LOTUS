package com.project.lotus.user.controller;

import com.project.lotus.favorite.dto.FavoriteDto;
import com.project.lotus.product.dto.ProductDto;
import com.project.lotus.product.dto.ProductForm;
import com.project.lotus.user.service.impl.UserServiceImpl;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {

    private final UserServiceImpl userServiceImpl;

    // 이용자 상품 등록 *24.01.25 jihyun
    @PostMapping(consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> productAdd(
            @RequestParam(value = "image") MultipartFile image,
            @Valid ProductForm.Request productForm,
            @RequestHeader(name = "Authorization") String token) throws IOException {

        userServiceImpl.addProduct(image, productForm, token);

        return ResponseEntity.status(CREATED).build();
    }

    // 이용자 상품 수정 *24.01.25 jihyun
    @PutMapping(value = "/{productIdx}", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> productModify(
            @RequestParam(value = "image") MultipartFile image,
            @Valid ProductForm.Request productForm,
            @PathVariable Long productIdx) throws IOException {

        userServiceImpl.modifyProduct(image, productForm, productIdx);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 상품 삭제 *24.01.25 jihyun
    @DeleteMapping("/{productIdx}")
    public ResponseEntity<Void> productRemove(
            @PathVariable Long productIdx
    ) throws IOException {

        userServiceImpl.removeProduct(productIdx);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 찜 상품 조회 *24.01.25 jihyun
    @GetMapping("/favorite")
    public ResponseEntity<List<FavoriteDto.Response>> favoriteList(
            @RequestHeader(name = "Authorization") String token) {

        List<FavoriteDto.Response> productDtoList = userServiceImpl.findFavoriteList(token);

        return ResponseEntity.status(OK)
                .body(productDtoList);
    }

    // 이용자 판매 상품 조회 *24.01.24 jihyun
    public ResponseEntity<List<ProductDto.Response>> sellingList(
            @RequestHeader(name = "Authorization") String token) {

        List<ProductDto.Response> productDtoList = userServiceImpl.findSellingList(token);

        return ResponseEntity.status(OK)
                .body(productDtoList);
    }
}
