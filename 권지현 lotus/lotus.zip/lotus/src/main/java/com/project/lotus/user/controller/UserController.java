package com.project.lotus.user.controller;

import com.project.lotus.auth.dto.SignupDto;
import com.project.lotus.auth.dto.UsersignupForm;
import com.project.lotus.favorite.dto.FavoriteDto;
import com.project.lotus.message.dto.MessageDto;
import com.project.lotus.message.service.impl.MessageServiceImpl;
import com.project.lotus.product.dto.ProductDto;
import com.project.lotus.product.dto.ProductForm;
import com.project.lotus.review.dto.ReviewDto;
import com.project.lotus.review.dto.ReviewForm;
import com.project.lotus.user.dto.QnaDto;
import com.project.lotus.user.dto.QnaForm;
import com.project.lotus.user.service.impl.UserServiceImpl;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

@RequestMapping("/user")
@RestController
@RequiredArgsConstructor
public class UserController {

    // Service *24.02.03 jihyun
    private final UserServiceImpl userServiceImpl;
    private final MessageServiceImpl messageServiceImpl;

    // 이용자 (마이 페이지) 정보 조회 *24.02.03 jihyun
    @GetMapping("/details")
    public ResponseEntity<SignupDto.Response> profileFind (
            @RequestHeader(name = "Authorization") String accessToken) {

        SignupDto.Response signupDto = userServiceImpl.findProfile(accessToken);

        return ResponseEntity.status(OK).body(signupDto);
    }

    // 이용자 (마이 페이지) 정보 수정 *24.02.03 jihyun
    @PutMapping("/details")
    public ResponseEntity<Void> profileModify (
            @RequestHeader(name = "Authorization") String accessToken,
            @Valid UsersignupForm.Request usersignupForm,
            @RequestPart(value = "image", required = false) MultipartFile image) throws IOException {

        userServiceImpl.modifyProfile(accessToken, usersignupForm, image);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 상품 등록 *24.01.25 jihyun
    @PostMapping(value = "/product", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> productAdd (
            @RequestHeader(name = "Authorization") String accessToken,
            @Valid ProductForm.Request productForm,
            @RequestPart(value = "images", required = false) List<MultipartFile> images) throws IOException {

        userServiceImpl.addProduct(accessToken, productForm, images);

        return ResponseEntity.status(CREATED).build();
    }

    // 이용자 상품 수정 *24.01.25 jihyun
    @PutMapping(value = "/product/{productIdx}", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> productModify (
            @PathVariable Long productIdx,
            @Valid ProductForm.Request productForm,
            @RequestPart(value = "images", required = false) List<MultipartFile> images) throws IOException {

        userServiceImpl.modifyProduct(productIdx, productForm, images);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 상품 삭제 *24.01.25 jihyun
    @DeleteMapping(value ="/product/{productIdx}")
    public ResponseEntity<Void> productRemove (
            @PathVariable Long productIdx) {

        userServiceImpl.removeProduct(productIdx);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 찜 등록 *24.01.31 jihyun
    @PostMapping(value ="/product/{productIdx}/favorite")
    public ResponseEntity<Void> favoriteAdd (
            @RequestHeader(name = "Authorization") String accessToken,
            @PathVariable Long productIdx) {

        userServiceImpl.addfavorite(accessToken, productIdx);

        return ResponseEntity.status(CREATED).build();
    }

    // 이용자 찜 삭제 *24.01.31 jihyun
    @DeleteMapping(value ="/product/{productIdx}/favorite")
    public ResponseEntity<Void> favoriteRemove (
            @PathVariable Long productIdx) {

        userServiceImpl.removeFavorite(productIdx);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 찜 상품 조회 *24.01.25 jihyun
    @GetMapping(value ="/product/favorite")
    public ResponseEntity<List<FavoriteDto.Response>> favoriteList (
            @RequestHeader(name = "Authorization") String accessToken) {

        List<FavoriteDto.Response> productDtoList = userServiceImpl.findFavoriteList(accessToken);

        return ResponseEntity.status(OK).body(productDtoList);
    }

    // 이용자 판매 상품 조회 *24.01.24 jihyun
    @GetMapping(value = "/product")
    public ResponseEntity<List<ProductDto.Response>> sellingList (
            @RequestHeader(name = "Authorization") String accessToken) {

        List<ProductDto.Response> productDtoList = userServiceImpl.findSellingList(accessToken);

        return ResponseEntity.status(OK).body(productDtoList);
    }

    // 이용자 리뷰 등록 *24.01.26 jihyun
    @PostMapping(value = "/product/{productIdx}/review", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> reviewAdd (
            @RequestHeader(name = "Authorization") String accessToken,
            @PathVariable Long productIdx,
            @Valid ReviewForm.Request reviewForm,
            @RequestPart(value = "images", required = false) List<MultipartFile> images) throws IOException {

        userServiceImpl.addReview(accessToken, productIdx, reviewForm, images);

        return ResponseEntity.status(CREATED).build();
    }

    // 이용자 리뷰 수정 *24.01.27 jihyun
    @PutMapping(value = "/product/{productIdx}/review/{reviewIdx}", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> reviewModify (
            @PathVariable Long reviewIdx,
            @Valid ReviewForm.Request reviewForm,
            @RequestPart(value = "images", required = false) List<MultipartFile> images) throws IOException {

        userServiceImpl.modifyReview(reviewIdx, reviewForm, images);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 리뷰 삭제 *24.01.27 jihyun
    @DeleteMapping(value = "/product/{productIdx}/review/{reviewIdx}")
    public ResponseEntity<Void> reviewRemove (
            @PathVariable Long reviewIdx) {

        userServiceImpl.removeReivew(reviewIdx);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 한 상품에 대한 모든 리뷰 조회 *24.01.24 jihyun
    @GetMapping(value = "/product/{productIdx}/review")
    public ResponseEntity<List<ReviewDto.Response>> reviewList (
            @PathVariable Long productIdx) {

        List<ReviewDto.Response> reviewDtoList = userServiceImpl.findReviewList(productIdx);

        return ResponseEntity.status(OK).body(reviewDtoList);
    }

    // 이용자 Q&A 게시판 등록 *24.01.28 jihyun
    @PostMapping(value = "/qna", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> qnaAdd (
            @RequestHeader(name = "Authorization") String accessToken,
            @Valid QnaForm.Request qnaForm,
            @RequestPart(value = "images", required = false) List<MultipartFile> images) throws IOException {

        userServiceImpl.addQna(accessToken, qnaForm, images);

        return ResponseEntity.status(CREATED).build();
    }

    // 이용자 Q&A 게시판 수정 *24.01.28 jihyun
    @PutMapping(value = "/qna/{qnaIdx}", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> qnaModify (
            @PathVariable Long qnaIdx,
            @Valid QnaForm.Request qnaForm,
            @RequestPart(value = "images", required = false) List<MultipartFile> images) throws IOException {

        userServiceImpl.modifyQna(qnaIdx, qnaForm, images);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 Q&A 게시판 삭제 *24.01.28 jihyun
    @DeleteMapping(value = "/qna/{qnaIdx}")
    public ResponseEntity<Void> qnaRemove (
            @PathVariable Long qnaIdx) {

        userServiceImpl.removeQna(qnaIdx);

        return ResponseEntity.status(NO_CONTENT).build();
    }

    // 이용자 Q&A 게시판 전체 조회 *24.01.28 jihyun
    @GetMapping("/qna-list")
    public ResponseEntity<List<QnaDto.Response>> qnaList () {

        List<QnaDto.Response> qnatDtoList = userServiceImpl.findQnaList();

        return ResponseEntity.status(OK).body(qnatDtoList);
    }

    // 이용자가 작성한 Q&A 게시판 전체 조회 *24.01.28 jihyun
    @GetMapping("/qna")
    public ResponseEntity<List<QnaDto.Response>> qnaList (
            @RequestHeader(name = "Authorization") String accessToken) {

        List<QnaDto.Response> qnatDtoList = userServiceImpl.findQnaList(accessToken);

        return ResponseEntity.status(OK).body(qnatDtoList);
    }

    // 이용자 메시지 보내기 *24.02.02 jihyun
    @PostMapping("/message")
    public ResponseEntity<MessageDto> messageAdd (
            @RequestHeader(name = "Authorization") String accessToken,
            MessageDto.Request messageDto) {

        messageServiceImpl.addMessage(accessToken, messageDto);

        return ResponseEntity.status(CREATED).build();
    }
}
