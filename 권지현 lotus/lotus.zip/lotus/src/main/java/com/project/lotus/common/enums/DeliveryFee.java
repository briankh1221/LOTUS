package com.project.lotus.common.enums;

public enum DeliveryFee {

    // 택배비 포함 *24.01.19 jihyun
    INCLUDING_DELIVERY_FEE,

    // 택배비 불포함 *24.01.19 jihyun
    NOT_INCLUDING_DELIVERY_FEE
}
