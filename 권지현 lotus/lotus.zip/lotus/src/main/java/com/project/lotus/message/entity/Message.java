package com.project.lotus.message.entity;

import com.project.lotus.auth.entity.User;
import com.project.lotus.common.BaseTimeEntity;
import com.project.lotus.message.dto.MessageDto;
import com.project.lotus.message.service.MessageService;
import com.project.lotus.product.entity.Product;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;

@Entity
@Getter @Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Message extends BaseTimeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long MessageIdx;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "buyer_id")
    private User buyer;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "seller_id")
    private Product seller;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "product_idx")
    private Product product;

    @NotNull
    private String content;

    @CreatedDate
    private LocalDateTime postingDate;

    public static Message from (User buyer, Product seller, Product product, MessageDto.Request messageDto)  {

        return Message.builder()
                .buyer(buyer)
                .seller(seller)
                .content(messageDto.getContent())
                .product(product)
                .build();
    }
}
