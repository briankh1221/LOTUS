package com.project.lotus.common.enums;

public enum ProductStatus {

    // 최상 *24.01.19 jihyun
    EXCELLENT,

    // 상 *24.01.19 jihyun
    GOOD,

    // 중 *24.01.19 jihyun
    FAIR,

    // 하 *24.01.19 jihyun
    POOR,

    // 최하 *24.01.19 jihyun
    VERY_POOR
}
