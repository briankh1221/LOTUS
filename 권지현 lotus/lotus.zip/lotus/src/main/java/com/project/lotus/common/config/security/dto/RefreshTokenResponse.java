package com.project.lotus.common.config.security.dto;

import lombok.Getter;

import java.util.Map;

@Getter
public class RefreshTokenResponse {

    private final String status;
    private final String message;

    public RefreshTokenResponse(Map<String, String> map) {
        this.status = map.get("status");
        this.message = map.get("message");
    }
}