package com.project.lotus.common.config.security.dto;

import lombok.Getter;

import java.util.Map;

@Getter
public class RefreshTokenResponse {

    // Refresh Token 상태 *24.01.24 jihyun
    private final String status;
    // Refresh Token 메시지 *24.01.24 jihyun
    private final String message;

    public RefreshTokenResponse(Map<String, String> map) {
        this.status = map.get("status");
        this.message = map.get("message");
    }
}