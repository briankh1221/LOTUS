package com.project.lotus.product.dto;

public class ProductCategoryDto {

    // 상품 카테고리 인덱스 *24.01.24 jihyun
    private Long categoryId;

    // 상품 카테고리 이름 *24.01.18 jihyun
    private String categoryName;
}
