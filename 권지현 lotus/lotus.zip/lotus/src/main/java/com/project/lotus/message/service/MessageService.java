package com.project.lotus.message.service;

import com.project.lotus.message.dto.MessageDto;


public interface MessageService {

    public void addMessage(String accessToken, MessageDto.Request messageDto);

}
