package com.project.lotus.admin.repository;

import com.project.lotus.admin.entity.QnaReply;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QnaReplyRepository extends JpaRepository<QnaReply,Long> {

}
