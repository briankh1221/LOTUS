package com.project.lotus.admin.controller;

import com.project.lotus.admin.repository.QnaReplyRepository;
import com.project.lotus.admin.service.impl.AdminServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/admin/product")
@RequiredArgsConstructor
public class QnaReplyController {




}
