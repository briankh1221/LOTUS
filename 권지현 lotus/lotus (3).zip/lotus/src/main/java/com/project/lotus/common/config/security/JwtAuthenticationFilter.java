package com.project.lotus.common.config.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    public static final String TOKEN_HEADER = "Authorization";
    // 인증 타입 *24.01.18 jihyun
    public static final String TOKEN_PREFIX = "Bearer ";

    private final TokenProvider tokenProvider;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        // 필터 실행 전 Token 추출함 *24.01.18 jihyun
        String AccessToken = resolveTokenFromRequest(request);

        // Access Token 유효성 검사 *24.01.18 jihyun
        if (StringUtils.hasText(AccessToken) && tokenProvider.validateToken(AccessToken)) {
            Authentication authentication = tokenProvider.getAuthentication(AccessToken);
            // SecurityContextHolder에 Authentication 저장 *24.01.23 jihyun
            SecurityContextHolder.getContext().setAuthentication(authentication);
        } else {
            System.out.println("유효한 JWT 토큰이 없습니다.");
//            logger.debug("유효한 JWT 토큰이 없습니다.");
        }
        // 다음 filter Chain 실행 *24.01.18 jihyun
        filterChain.doFilter(request, response);
    }

    // HTTP Header에서 Access Token 추출 *24 01 23
    private String resolveTokenFromRequest(HttpServletRequest request) {

        String token = request.getHeader(TOKEN_HEADER);

        if (StringUtils.hasText(token) && token.startsWith(TOKEN_PREFIX)) {
            return token.substring(TOKEN_PREFIX.length());
        }

        return token;
    }
}
