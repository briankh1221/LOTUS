package com.project.security.controller;

import com.project.security.data.dto.SignInResultDto;
import com.project.security.data.dto.SignUpResultDto;
import com.project.security.service.SignService;
import com.project.security.service.impl.SignServiceImpl;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/sign-api")
public class SignController {

    private final SignService SignService;

    @Autowired
    public SignController(SignService SignService) {
        this.SignService = SignService;
    }

    @PostMapping(value = "/sign-in")
    public SignInResultDto signIn(
            @RequestParam("id") String id,
            @RequestParam("password") String password) throws RuntimeException {
        SignInResultDto signInResultDto = SignService.signIn(id, password);
        if(signInResultDto.getCode() == 0) {
            signInResultDto.getToken();
        }
        return signInResultDto;
    }

    @PostMapping(value = "/sign-up")
    public SignUpResultDto signUp (
            @RequestParam("id") String id,
            @RequestParam("password") String password,
            @RequestParam("name") String name,
            @RequestParam("role") String role) {
        SignUpResultDto signUpResultDto = SignService.signUp(id, password, name, role);
        return signUpResultDto;
    }

    @GetMapping(value = "/exception")
    public void exceptionTest() throws RuntimeException {
        throw new RuntimeException("접근이 금지 되었습니다");
    }

    /* @ExceptionHandler(value = RuntimeException.class)
    public ResponseEntity<Map<String, String>> ExceptionHandler(RuntimeException e) {
        HttpHeaders responseHeaders = new HttpHeaders();
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;

        Map<String, String> map = new HashMap<>();

        map.put("error type", httpStatus.getReasonPhrase());
        map.put("code", "400");
        map.put("message", "에러 발생");

        return new ResponseEntity<>(map, responseHeaders, httpStatus);
    } */



}
