<template>
    <app-header></app-header>
    <app-nav></app-nav>
    <app-view></app-view>
</template>
<script>
export default {};
</script>
