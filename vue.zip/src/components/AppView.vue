<template>
    <main>
        <section>
            <book-component></book-component>
            <book-component></book-component>
            <book-component></book-component>
            <book-component></book-component>
            <book-component></book-component>
        </section>
    </main>
</template>
<script>
export default {};
</script>

