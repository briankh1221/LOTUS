<template>
	<main>
		<LifeCycleHooks></LifeCycleHooks>
	</main>
</template>

<script>
import LifeCycleHooks from './LifeCycleHooks.vue';

export default {
	components: {
		LifeCycleHooks,
	},
	setup() {
		return {};
	},
};
</script>

<style lang="scss" scoped></style>
