<template>
	<main>
		<div class="container py-4">
			<MyButton class="my-button" id="my-button" @click="sayHello"></MyButton>
			<LabelInput label="이름" data-id="id입니다"></LabelInput>
			<hr />
			<FancyButton>Click! <span style="color: red">@@@</span></FancyButton>
			<FancyButton v-slot="{ fancyMessage }">{{ fancyMessage }}</FancyButton>
			<hr />
			<AppCard>
				<template #[slotArgs]="{ headerMessage }">{{ headerMessage }}</template>
				<template #default="{ childMessage, helloMessage }">
					내용입니다 <br />{{ childMessage }} <br />
					{{ helloMessage }}</template
				>
				<!-- 암시적으로 default slot 입니다 -->
				<template v-slot:footer="{ footerMessage }">
					{{ footerMessage }}
				</template>
			</AppCard>
			<hr />
			<AppCard>게시글입니다</AppCard>
		</div>
	</main>
</template>

<script>
import MyButton from '@/components/MyButton.vue';
import LabelInput from '@/components/LabelInput.vue';
import FancyButton from './FancyButton.vue';
import AppCard from './AppCard.vue';
import { ref } from 'vue';

export default {
	components: {
		MyButton,
		LabelInput,
		FancyButton,
		AppCard,
	},
	setup() {
		const sayHello = () => {
			alert('안녕하세요');
		};
		const slotArgs = ref('header');
		return { sayHello, slotArgs };
	},
};
</script>

<style lang="scss" scoped></style>
