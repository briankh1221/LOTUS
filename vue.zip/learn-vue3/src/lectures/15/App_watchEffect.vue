<template>
	<div>
		<form action="">
			<input type="text" v-model="title" placeholder="title" />
			<textarea v-model="contents" placeholder="contents"></textarea>
		</form>
	</div>
</template>

<script>
import { ref, watchEffect } from 'vue';

export default {
	setup() {
		const title = ref('');
		const contents = ref('');

		watchEffect(() => {
			console.log('watchEffect');
			console.log(title.value);
			console.log(contents.value);
		});

		return { title, contents };
	},
};
</script>

<style lang="scss" scoped></style>
