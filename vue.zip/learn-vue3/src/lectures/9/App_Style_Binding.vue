<template>
	<div>
		<div :style="styleObject">
			Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem
			modi labore vel maxime, culpa itaque. Inventore animi, minima nihil saepe
			aliquid a nam natus ducimus quaerat, deserunt officiis, similique
			perferendis.
		</div>
		<button v-on:click="fontSize++">++</button>
		<button v-on:click="fontSize--">--</button>
	</div>
</template>

<script>
import { computed, ref } from 'vue';

export default {
	setup() {
		// const styleObject = reactive({
		// 	color: 'red',
		// 	fontSize: '13px',
		// });

		const fontSize = ref('13');
		const styleObject = computed(() => {
			return {
				color: 'red',
				fontSize: fontSize.value + 'px',
			};
		});
		return { styleObject, fontSize };
	},
};
</script>

<style lang="scss" scoped></style>
