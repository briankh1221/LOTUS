<template>
	<div>
		<div class="text" :class="{ active: isActive, 'text-danger': hasError }">
			텍스트 입니다.
		</div>
		<div class="text" :class="classObject">오브젝트 텍스트 입니다.</div>
		<button v-on:click="toggle">toggle</button>
		<button v-on:click="hasError = !hasError">toggleError</button>
	</div>
</template>

<script>
import { reactive, ref } from 'vue';

export default {
	setup() {
		const isActive = ref(true);
		const hasError = ref(true);
		const classObject = reactive({
			active: true,
			'text-danger': false,
		});

		const toggle = () => {
			isActive.value = !isActive.value;
		};
		return { isActive, hasError, toggle, classObject };
	},
};
</script>

<style scoped>
.active {
	font-weight: 900;
}
.text-danger {
	color: red;
}
</style>
